import { useOutletContext } from "react-router-dom";
import Hero from "../components/Hero.jsx";
import About from "../components/About.jsx";
import Expertise from "../components/Expertise.jsx";
import SpotlightTeasers from "../components/SpotlightTeasers.jsx";
import ProjectsTeaser from "../components/projects/ProjectsTeaser.jsx";
import Experience from "../components/Experience.jsx";
import Approach from "../components/Approach.jsx";
import Skills from "../components/Skills.jsx";
import Certifications from "../components/Certifications.jsx";
import Contact from "../components/Contact.jsx";

export default function HomePage() {
  const { profile } = useOutletContext();

  return (
    <main className="home-main" id="main-content">
      <Hero profile={profile} />
      <About profile={profile} />
      <Expertise items={profile.expertise} />
      <SpotlightTeasers razhmanFocus={profile.razhmanFocus} foundation={profile.foundation} />
      <ProjectsTeaser catalog={profile.projectCatalog} projects={profile.projects} />
      <Experience jobs={profile.experience} />
      <Approach steps={profile.approach} />
      <Skills skills={profile.skills} />
      <Certifications certs={profile.certifications} languages={profile.languages} />
      <Contact profile={profile} />
    </main>
  );
}
