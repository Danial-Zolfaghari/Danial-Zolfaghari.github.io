import { useOutletContext } from "react-router-dom";
import SceneBackdrop from "../components/effects/SceneBackdrop.jsx";
import Hero from "../components/Hero.jsx";
import Marquee from "../components/Marquee.jsx";
import About from "../components/About.jsx";
import Expertise from "../components/Expertise.jsx";
import Approach from "../components/Approach.jsx";
import Skills from "../components/Skills.jsx";
import Experience from "../components/Experience.jsx";
import SpotlightTeasers from "../components/SpotlightTeasers.jsx";
import ProjectsTeaser from "../components/projects/ProjectsTeaser.jsx";
import Certifications from "../components/Certifications.jsx";
import Contact from "../components/Contact.jsx";

export default function HomePage() {
  const { profile } = useOutletContext();

  return (
    <main className="home-main">
      <SceneBackdrop variant="page" className="home-backdrop" />
      <Hero profile={profile} />
      <Marquee items={profile.marquee} />
      <About profile={profile} />
      <Expertise items={profile.expertise} />
      <Approach steps={profile.approach} />
      <Skills skills={profile.skills} />
      <Experience jobs={profile.experience} />
      <SpotlightTeasers razhmanFocus={profile.razhmanFocus} foundation={profile.foundation} />
      <ProjectsTeaser catalog={profile.projectCatalog} projects={profile.projects} />
      <Certifications
        certs={profile.certifications}
        languages={profile.languages}
      />
      <Contact profile={profile} />
    </main>
  );
}
