import { useEffect, useMemo, useState } from "react";
import { useOutletContext, useSearchParams } from "react-router-dom";
import { FaMagnifyingGlass, FaTableCellsLarge, FaList, FaStar } from "react-icons/fa6";
import ProjectCard from "../components/projects/ProjectCard.jsx";
import { filterProjects, groupProjects, sortProjects } from "../utils/projectHelpers.js";
import { useReveal } from "../hooks/useReveal.js";

export default function ProjectsPage() {
  const { profile } = useOutletContext();
  const catalog = profile.projectCatalog || {};
  const categories = catalog.categories || ["All"];
  const [searchParams] = useSearchParams();
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [view, setView] = useState("grid");
  const { ref, visible } = useReveal(0.05);

  useEffect(() => {
    const cat = searchParams.get("category");
    if (cat && categories.includes(cat)) {
      setCategory(cat);
    }
  }, [searchParams, categories]);

  const filtered = useMemo(
    () => sortProjects(filterProjects(profile.projects, category, query)),
    [profile.projects, category, query]
  );

  const grouped = useMemo(
    () => groupProjects(filtered, category, query, catalog.groups),
    [filtered, category, query, catalog.groups]
  );

  const topPickCount = profile.projects?.filter((p) => p.topPick).length || 0;
  const razhmanCount = profile.projects?.filter((p) => p.segment === "Razhman").length || 0;
  const fivemCount = profile.projects?.filter((p) => p.segment === "FiveM").length || 0;

  let cardIndex = 0;

  return (
    <main className="showcase-page">
      <section className="showcase-hero">
        <div className="showcase-hero-bg" aria-hidden="true">
          <div className="showcase-hero-grid" />
          <div className="showcase-hero-glow" />
        </div>

        <div className="container showcase-hero-inner">
          <p className="showcase-hero-label">Project Showcase</p>
          <h1>{catalog.title || "Selected Work"}</h1>
          <p className="showcase-hero-desc">
            {catalog.description || "Production systems engineered for real operations."}
          </p>

          <div className="showcase-hero-stats">
            <div>
              <strong>{topPickCount}</strong>
              <span>Top Picks</span>
            </div>
            <div>
              <strong>{razhmanCount}</strong>
              <span>Razhman</span>
            </div>
            <div>
              <strong>{fivemCount}</strong>
              <span>FiveM</span>
            </div>
          </div>
        </div>
      </section>

      <section className="showcase-toolbar-wrap">
        <div className="container showcase-toolbar">
          <div className="showcase-search">
            <FaMagnifyingGlass />
            <input
              type="search"
              placeholder="Search projects, technologies…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search projects"
            />
          </div>

          <div className="showcase-filters" role="tablist">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={category === cat}
                className={category === cat ? "active" : ""}
                onClick={() => setCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="showcase-view-toggle">
            <button
              type="button"
              className={view === "grid" ? "active" : ""}
              onClick={() => setView("grid")}
              aria-label="Grid view"
            >
              <FaTableCellsLarge />
            </button>
            <button
              type="button"
              className={view === "list" ? "active" : ""}
              onClick={() => setView("list")}
              aria-label="List view"
            >
              <FaList />
            </button>
          </div>
        </div>
      </section>

      <section className="showcase-grid-section">
        <div className="container">
          <p className="showcase-count">
            {filtered.length} project{filtered.length !== 1 ? "s" : ""} shown
            {category === "All" && !query.trim() && " · Razhman first, then FiveM"}
          </p>

          <div ref={ref} className={visible ? "reveal--visible" : "reveal"}>
            {grouped.map((group) => (
              <div key={group.id} className="showcase-group">
                {group.label && (
                  <header className="showcase-group-head">
                    <div>
                      <h2>
                        <FaStar className="showcase-group-icon" aria-hidden="true" />
                        {group.label}
                      </h2>
                      {group.description && <p>{group.description}</p>}
                    </div>
                  </header>
                )}

                <div className={`showcase-grid showcase-grid--${view}`}>
                  {group.projects.map((p) => {
                    const index = cardIndex;
                    cardIndex += 1;
                    return (
                      <ProjectCard
                        key={p.slug || p.name}
                        project={p}
                        index={index}
                        layout={view}
                      />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="showcase-empty glass-card">
              <p>No projects match your search.</p>
              <button type="button" className="btn btn-ghost" onClick={() => { setQuery(""); setCategory("All"); }}>
                Clear filters
              </button>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
