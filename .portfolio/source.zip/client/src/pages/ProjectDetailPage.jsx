import { useEffect, useMemo, useState } from "react";
import { Link, Navigate, useOutletContext, useParams } from "react-router-dom";
import {
  FaArrowLeft, FaArrowRight, FaStar, FaChevronRight,
} from "react-icons/fa6";
import { TechIcon } from "../utils/techIcons.jsx";
import CasePipeline from "../components/projects/CasePipeline.jsx";
import ProjectVisual from "../components/visuals/ProjectVisual.jsx";
import ProjectAnalyticsPanel from "../components/visuals/ProjectAnalyticsPanel.jsx";
import {
  findProjectBySlug,
  getAdjacentProjects,
  getProjectSlug,
} from "../utils/projectHelpers.js";
import SystemName from "../components/SystemName.jsx";

const BASE_TABS = [
  { id: "overview", label: "Overview" },
  { id: "features", label: "Features" },
  { id: "architecture", label: "Architecture" },
  { id: "stack", label: "Stack" },
];

export default function ProjectDetailPage() {
  const { slug } = useParams();
  const { profile, openContact } = useOutletContext();
  const project = findProjectBySlug(profile.projects, slug);
  const [tab, setTab] = useState("overview");
  const { prev, next } = getAdjacentProjects(profile.projects, slug);

  const cs = project?.caseStudy || {};

  const tabs = useMemo(() => {
    const list = [...BASE_TABS];
    if (cs.pipeline?.length) list.splice(1, 0, { id: "pipeline", label: "Pipeline" });
    if (cs.principles?.length) list.splice(list.length - 1, 0, { id: "principles", label: "Principles" });
    if (cs.models?.length) list.splice(list.length - 1, 0, { id: "models", label: "AI Models" });
    return list;
  }, [cs.pipeline, cs.principles, cs.models]);

  useEffect(() => {
    window.scrollTo(0, 0);
    setTab("overview");
  }, [slug]);

  if (!project) return <Navigate to="/work" replace />;

  const accent = project.accent || "#34d399";

  return (
    <main className="case-page" id="main-content" style={{ "--project-accent": accent }}>
      <section className="case-hero">
        <div className="case-hero-bg" aria-hidden="true">
          <div className="case-hero-glow" />
          <div className="case-hero-grid" />
          <div className="case-hero-noise" />
        </div>

        <div className="container case-hero-split">
          <div className="case-hero-inner">
          <nav className="case-breadcrumb" aria-label="Breadcrumb">
            <Link to="/">Home</Link>
            <FaChevronRight />
            <Link to="/work">Projects</Link>
            <FaChevronRight />
            <span>{project.name}</span>
          </nav>

          <div className="case-hero-meta">
            {project.featured && (
              <span className="showcase-badge showcase-badge--featured">
                <FaStar /> Featured
              </span>
            )}
            {project.category && (
              <span className="showcase-badge showcase-badge--cat">{project.category}</span>
            )}
            {project.status && (
              <span className="showcase-badge showcase-badge--status">{project.status}</span>
            )}
            {project.version && (
              <span className="showcase-badge showcase-badge--version">v{project.version}</span>
            )}
          </div>

          {project.tagline && <p className="case-tagline">{project.tagline}</p>}
          <SystemName name={project.name} expansion={project.expansion} as="h1" className="case-system-name" />
          {project.subtitle && <p className="case-subtitle">{project.subtitle}</p>}
          <p className="case-summary">{project.summary || project.description}</p>

          <div className="case-hero-info">
            <div>
              <span className="card-label">Role</span>
              <strong>{project.role}</strong>
            </div>
            {project.company && (
              <div>
                <span className="card-label">Company</span>
                <strong>{project.company}</strong>
              </div>
            )}
            {project.team && (
              <div>
                <span className="card-label">Team</span>
                <strong>{project.team}</strong>
              </div>
            )}
            {project.completed && (
              <div>
                <span className="card-label">Completed</span>
                <strong>{project.completed}</strong>
              </div>
            )}
            {project.year && (
              <div>
                <span className="card-label">Timeline</span>
                <strong>{project.year}</strong>
              </div>
            )}
          </div>

          {project.metrics?.length > 0 && (
            <div className="case-metrics">
              {project.metrics.map((m) => (
                <div key={m.label} className="case-metric">
                  <strong>{m.value ?? m}</strong>
                  <span>{m.label ?? ""}</span>
                </div>
              ))}
            </div>
          )}
          </div>

          <div className="case-hero-visual">
            <ProjectVisual project={project} expanded />
          </div>
        </div>
      </section>

      <div className="case-sticky-nav">
        <div className="container case-tabs" role="tablist">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              className={tab === t.id ? "active" : ""}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <section className="case-content">
        <div className="container case-layout">
          <div className="case-main">
            {tab === "overview" && (
              <div className="case-panel">
                <div className="case-block glass-card">
                  <span className="card-label">Overview</span>
                  <p>{project.description}</p>
                </div>

                <ProjectAnalyticsPanel project={project} />

                {cs.challenge && (
                  <div className="case-block glass-card">
                    <span className="card-label">The Challenge</span>
                    <p>{cs.challenge}</p>
                  </div>
                )}

                {cs.solution && (
                  <div className="case-block glass-card case-block--accent">
                    <span className="card-label">The Solution</span>
                    <p>{cs.solution}</p>
                  </div>
                )}

                {project.impact && (
                  <div className="case-block glass-card">
                    <span className="card-label">Impact</span>
                    <p>{project.impact}</p>
                  </div>
                )}

                {cs.results?.length > 0 && (
                  <div className="case-block glass-card">
                    <span className="card-label">Key Results</span>
                    <ul className="case-results">
                      {cs.results.map((r) => (
                        <li key={r}>{r}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {project.highlights?.length > 0 && (
                  <div className="case-block glass-card">
                    <span className="card-label">Engineering Highlights</span>
                    <ul className="case-highlights">
                      {project.highlights.map((h) => (
                        <li key={h}>{h}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {tab === "pipeline" && (
              <div className="case-panel">
                <div className="case-pipeline-visual-wrap glass-card">
                  <ProjectVisual project={project} compact />
                </div>
                <div className="case-block glass-card case-block--intro">
                  <span className="card-label">Investigation Pipeline</span>
                  <p>End-to-end flow from natural language to validated Elasticsearch execution.</p>
                </div>
                <CasePipeline steps={cs.pipeline} />
              </div>
            )}

            {tab === "principles" && (
              <div className="case-panel case-principles">
                {cs.principles?.map((p, i) => (
                  <div key={p.title} className="case-principle glass-card" style={{ "--i": i }}>
                    <span className="case-principle-num">{String(i + 1).padStart(2, "0")}</span>
                    <div>
                      <h4>{p.title}</h4>
                      <p>{p.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === "models" && (
              <div className="case-panel">
                <div className="case-models-grid">
                  {cs.models?.map((m) => (
                    <div key={m.role} className="case-model glass-card">
                      <span className="card-label">{m.role}</span>
                      <strong>{m.model}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "features" && (
              <div className="case-panel">
                {cs.featureGroups?.map((group) => (
                  <div key={group.title} className="case-block glass-card">
                    <span className="card-label">{group.title}</span>
                    <ul className="case-feature-grid">
                      {group.items.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
                {!cs.featureGroups?.length && (
                  <p className="case-empty">Feature breakdown coming soon.</p>
                )}
              </div>
            )}

            {tab === "architecture" && (
              <div className="case-panel">
                {cs.architecture?.map((layer, i) => (
                  <div key={layer.layer} className="case-arch-row glass-card" style={{ "--i": i }}>
                    <span className="case-arch-label">{layer.layer}</span>
                    <p>{layer.detail}</p>
                  </div>
                ))}
                {!cs.architecture?.length && (
                  <p className="case-empty">Architecture details coming soon.</p>
                )}
              </div>
            )}

            {tab === "stack" && (
              <div className="case-panel">
                <div className="case-stack-grid">
                  {project.technologies?.map((t) => (
                    <span key={t} className="case-stack-item glass-card">
                      <TechIcon name={t} size={18} />
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <aside className="case-sidebar">
            {cs.pipeline?.length > 0 && tab !== "pipeline" && (
              <div className="case-sidebar-card glass-card">
                <span className="card-label">Quick Pipeline</span>
                <ol className="case-sidebar-pipeline">
                  {cs.pipeline.slice(0, 4).map((s) => (
                    <li key={s.step}>{s.title}</li>
                  ))}
                </ol>
                <button type="button" className="case-sidebar-link" onClick={() => setTab("pipeline")}>
                  View full pipeline →
                </button>
              </div>
            )}

            <div className="case-sidebar-card glass-card">
              <span className="card-label">Technologies</span>
              <div className="case-sidebar-tech">
                {project.technologies?.map((t) => (
                  <span key={t}><TechIcon name={t} size={13} /> {t}</span>
                ))}
              </div>
            </div>

            <div className="case-sidebar-card glass-card case-sidebar-cta">
              <span className="card-label">Interested?</span>
              <p>Let's discuss how similar systems can solve your operational challenges.</p>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => openContact?.()}>
                Get in touch
              </button>
            </div>
          </aside>
        </div>
      </section>

      <section className="case-nav-section">
        <div className="container case-nav-grid">
          {prev ? (
            <Link to={`/work/${getProjectSlug(prev)}`} className="case-nav-link case-nav-link--prev glass-card">
              <span className="card-label">Previous</span>
              <strong>{prev.name}</strong>
              <FaArrowLeft />
            </Link>
          ) : <div />}

          <Link to="/work" className="case-nav-all btn btn-ghost">All projects</Link>

          {next ? (
            <Link to={`/work/${getProjectSlug(next)}`} className="case-nav-link case-nav-link--next glass-card">
              <span className="card-label">Next</span>
              <strong>{next.name}</strong>
              <FaArrowRight />
            </Link>
          ) : <div />}
        </div>
      </section>
    </main>
  );
}
