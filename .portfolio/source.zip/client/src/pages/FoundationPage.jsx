import { useOutletContext } from "react-router-dom";
import EngineeringFoundation from "../components/EngineeringFoundation.jsx";

export default function FoundationPage() {
  const { profile } = useOutletContext();

  return (
    <main className="foundation-page" id="main-content">
      <EngineeringFoundation foundation={profile.foundation} fullPage />
    </main>
  );
}
