import fallback from "../data/profile.json";

export function useProfile() {
  // GitHub Pages is static. Keep profile data inside the frontend bundle so the
  // portfolio never depends on an API endpoint to render.
  return { profile: fallback, loading: false };
}
