import fallback from "../data/profile.json";

export function useProfile() {
  return { profile: fallback, loading: false };
}
