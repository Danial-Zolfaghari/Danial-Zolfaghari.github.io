import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { scrollToSection } from "../utils/scrollToSection.js";

/** Scroll to hash target after route change (e.g. /work → /#contact) */
export function useHashScroll(enabled = true) {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (!enabled || pathname !== "/" || !hash) return undefined;

    const sectionId = hash.replace("#", "");
    if (!sectionId) return undefined;

    let attempts = 0;
    let timer = 0;

    const tick = () => {
      if (scrollToSection(sectionId) || attempts >= 40) return;
      attempts += 1;
      timer = window.setTimeout(tick, 50);
    };

    timer = window.setTimeout(tick, 60);
    return () => window.clearTimeout(timer);
  }, [pathname, hash, enabled]);
}
