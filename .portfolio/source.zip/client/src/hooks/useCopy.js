import { useCallback, useState } from "react";

export function useCopy() {
  const [copied, setCopied] = useState("");

  const copy = useCallback(async (text, key = "default") => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(""), 2000);
      return true;
    } catch {
      return false;
    }
  }, []);

  return { copy, copied };
}
