import { Link, useLocation, useNavigate } from "react-router-dom";
import { navigateToSection } from "../utils/scrollToSection.js";

export default function Footer({ name, title }) {
  const year = new Date().getFullYear();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const goContact = (e) => {
    e.preventDefault();
    navigateToSection(navigate, pathname, "contact");
  };

  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-brand">
          <strong>{name}</strong>
          <span>{title}</span>
        </div>
        <p className="footer-copy">© {year} — Crafted with intent.</p>
        <nav className="footer-nav" aria-label="Footer">
          <Link to="/">Home</Link>
          <Link to="/work">Projects</Link>
          <a href="/#contact" onClick={goContact}>Contact</a>
        </nav>
      </div>
    </footer>
  );
}
