import { FaAward, FaLanguage, FaCertificate } from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";

export default function Certifications({ certs, languages }) {
  const { ref, visible } = useReveal();

  const certList = certs?.map((c) => (typeof c === "string" ? { name: c } : c)) || [];

  return (
    <section className="section" id="certs">
      <div className="container">
        <SectionHead num="07" title="Credentials" subtitle="Certifications, training & languages" icon={FaCertificate} />
        <div ref={ref} className={`creds-bento${visible ? " reveal--visible" : " reveal"}`}>
          <div className="cred-block glass-card">
            <h3><FaAward /> Certifications & training</h3>
            <ul className="cert-list">
              {certList.map((c) => (
                <li key={c.name}>
                  <div className="cert-badge" aria-hidden="true">✓</div>
                  <div>
                    <strong>{c.name}</strong>
                    {(c.issuer || c.year) && (
                      <span>{[c.issuer, c.year].filter(Boolean).join(" · ")}</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="cred-block glass-card">
            <h3><FaLanguage /> Languages</h3>
            <ul className="lang-list">
              {languages?.map((l) => (
                <li key={l.name}>
                  <div className="lang-head">
                    <strong>{l.name}</strong>
                    <span>{l.level}</span>
                  </div>
                  {l.percent != null && (
                    <div className="lang-bar">
                      <div className="lang-fill" style={{ width: `${l.percent}%` }} />
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
