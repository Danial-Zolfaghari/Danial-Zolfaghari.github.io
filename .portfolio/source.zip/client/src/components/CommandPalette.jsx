import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { navigateToSection } from "../utils/scrollToSection.js";
import { FaMagnifyingGlass, FaArrowRight } from "react-icons/fa6";
import { getProjectSlug } from "../utils/projectHelpers.js";

const SECTIONS = [
  { id: "home", label: "Home", href: "/" },
  { id: "about", label: "About Me", href: "/#about" },
  { id: "expertise", label: "Core Expertise", href: "/#expertise" },
  { id: "skills", label: "Skills & Stack", href: "/#skills" },
  { id: "work", label: "All Projects", href: "/work" },
  { id: "foundation", label: "Engineering Foundation (FiveM)", href: "/foundation" },
  { id: "contact", label: "Contact", href: "/#contact" },
];

export default function CommandPalette({ skills = [], projects = [], open, onClose }) {
  const [query, setQuery] = useState("");
  const [index, setIndex] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();

  const actions = useMemo(() => {
    const items = [
      ...SECTIONS.map((s) => ({ type: "page", ...s })),
      ...projects.map((p) => ({
        type: "project",
        id: getProjectSlug(p),
        label: p.expansion ? `${p.name} · ${p.expansion}` : p.name,
        href: `/work/${getProjectSlug(p)}`,
        sub: [p.role, p.company, p.team === "Solo" ? "Solo" : null].filter(Boolean).join(" · "),
      })),
    ];

    const skillItems = (skills || []).flatMap((g) =>
      g.items.slice(0, 3).map((item) => ({
        type: "skill",
        id: item,
        label: item,
        href: "/#skills",
        sub: g.category,
      }))
    );

    return [...items, ...skillItems];
  }, [skills, projects]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return actions.slice(0, 12);
    return actions.filter(
      (a) =>
        a.label.toLowerCase().includes(q) ||
        a.sub?.toLowerCase().includes(q)
    ).slice(0, 10);
  }, [actions, query]);

  useEffect(() => {
    setIndex(0);
  }, [query]);

  useEffect(() => {
    if (!open) {
      setQuery("");
      setIndex(0);
    }
  }, [open]);

  const go = (item) => {
    if (item.href.startsWith("/#")) {
      navigateToSection(navigate, location.pathname, item.href.slice(2));
    } else {
      navigate(item.href);
    }
    onClose();
  };

  useEffect(() => {
    if (!open) return;

    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setIndex((i) => Math.min(i + 1, filtered.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === "Enter" && filtered[index]) {
        e.preventDefault();
        go(filtered[index]);
      }
    };

    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, filtered, index, onClose]);

  if (!open) return null;

  return (
    <div className="cmd-overlay" onClick={onClose} role="presentation">
      <div className="cmd-palette glass-card" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="Command palette">
        <div className="cmd-search">
          <FaMagnifyingGlass />
          <input
            type="text"
            placeholder="Jump to page, project, or skill…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            aria-label="Search"
          />
          <kbd>ESC</kbd>
        </div>

        <ul className="cmd-results">
          {filtered.length === 0 && (
            <li className="cmd-empty">No results for "{query}"</li>
          )}
          {filtered.map((item, i) => (
            <li key={`${item.type}-${item.id}`}>
              <button
                type="button"
                className={i === index ? "active" : ""}
                onClick={() => go(item)}
                onMouseEnter={() => setIndex(i)}
              >
                <div>
                  <strong>{item.label}</strong>
                  {item.sub && <span>{item.sub}</span>}
                </div>
                <span className="cmd-type">{item.type}</span>
                <FaArrowRight />
              </button>
            </li>
          ))}
        </ul>

        <div className="cmd-footer">
          <span><kbd>↑↓</kbd> navigate</span>
          <span><kbd>↵</kbd> go</span>
          <span><kbd>Ctrl</kbd>+<kbd>K</kbd> toggle</span>
        </div>
      </div>
    </div>
  );
}
