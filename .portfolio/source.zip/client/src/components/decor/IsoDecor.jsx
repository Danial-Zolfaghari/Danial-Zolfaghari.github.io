/** Lightweight CSS 3D decorative scenes for site sections */
const VARIANTS = {
  hero: {
    layers: [
      { label: "Security", color: "emerald", z: 0, size: 88 },
      { label: "Backend", color: "cyan", z: 28, size: 72 },
      { label: "AI / Data", color: "violet", z: 56, size: 56 },
    ],
    float: true,
  },
  network: {
    layers: [
      { label: "SOC", color: "emerald", z: 0, size: 76 },
      { label: "API", color: "cyan", z: 24, size: 64 },
      { label: "ES", color: "violet", z: 48, size: 52 },
    ],
    float: true,
  },
  about: {
    layers: [
      { label: "DZ", color: "emerald", z: 0, size: 64 },
      { label: "Eng", color: "cyan", z: 22, size: 52 },
    ],
    float: false,
  },
  contact: {
    layers: [
      { label: "→", color: "emerald", z: 0, size: 56 },
      { label: "✉", color: "cyan", z: 20, size: 48 },
    ],
    float: true,
  },
};

export default function IsoDecor({ variant = "hero", className = "" }) {
  const config = VARIANTS[variant] || VARIANTS.hero;

  return (
    <div
      className={`iso-decor iso-decor--${variant}${config.float ? " iso-decor--float" : ""}${className ? ` ${className}` : ""}`}
      aria-hidden="true"
    >
      <div className="iso-decor-orbit" />
      <div className="iso-decor-stack">
        {config.layers.map((layer, i) => (
          <div
            key={layer.label}
            className={`iso-decor-layer iso-decor-layer--${layer.color}`}
            style={{
              "--layer-z": layer.z,
              "--layer-size": `${layer.size}px`,
              "--layer-i": i,
            }}
          >
            <span>{layer.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
