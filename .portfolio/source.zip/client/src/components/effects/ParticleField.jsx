import { useEffect, useRef } from "react";

function createParticles(count, w, h) {
  return Array.from({ length: count }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    z: Math.random(),
    vx: (Math.random() - 0.5) * 0.35,
    vy: (Math.random() - 0.5) * 0.35,
  }));
}

export default function ParticleField({
  className = "",
  density = "medium",
  accent = "#2dd4a8",
  accent2 = "#38bdf8",
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;

    const ctx = canvas.getContext("2d");
    const countMap = { low: 40, medium: 70, high: 110 };
    let particles = [];
    let w = 0;
    let h = 0;
    let raf = 0;

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = parent.clientWidth;
      h = parent.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      particles = createParticles(countMap[density] || 70, w, h);
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas.parentElement);

    const draw = () => {
      ctx.clearRect(0, 0, w, h);

      particles.forEach((p) => {
        p.x += p.vx * (0.5 + p.z);
        p.y += p.vy * (0.5 + p.z);
        if (p.x < 0) p.x = w;
        if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h;
        if (p.y > h) p.y = 0;
      });

      for (let i = 0; i < particles.length; i += 1) {
        for (let j = i + 1; j < particles.length; j += 1) {
          const a = particles[i];
          const b = particles[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.hypot(dx, dy);
          const max = 100 + (a.z + b.z) * 40;
          if (dist < max) {
            const alpha = (1 - dist / max) * 0.22 * (a.z + b.z) * 0.5;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            const color = i % 2 === 0 ? accent : accent2;
            ctx.strokeStyle = color.startsWith("#")
              ? `rgba(${parseInt(color.slice(1, 3), 16)}, ${parseInt(color.slice(3, 5), 16)}, ${parseInt(color.slice(5, 7), 16)}, ${alpha})`
              : color;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }

        const p = particles[i];
        const size = 1 + p.z * 1.8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fillStyle = i % 3 === 0 ? accent : accent2;
        ctx.globalAlpha = 0.35 + p.z * 0.45;
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [density, accent, accent2]);

  return (
    <canvas
      ref={canvasRef}
      className={`particle-field${className ? ` ${className}` : ""}`}
      aria-hidden="true"
    />
  );
}
