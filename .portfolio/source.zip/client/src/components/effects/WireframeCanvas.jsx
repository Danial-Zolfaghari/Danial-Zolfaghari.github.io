import { useEffect, useRef } from "react";

const VERTICES = [
  [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
  [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1],
  [0, 0, 0],
];

const EDGES = [
  [0, 1], [1, 2], [2, 3], [3, 0],
  [4, 5], [5, 6], [6, 7], [7, 4],
  [0, 4], [1, 5], [2, 6], [3, 7],
  [0, 8], [1, 8], [2, 8], [3, 8],
  [4, 8], [5, 8], [6, 8], [7, 8],
];

function rotatePoint([x, y, z], ax, ay, az) {
  let x1 = x;
  let y1 = y * Math.cos(ax) - z * Math.sin(ax);
  let z1 = y * Math.sin(ax) + z * Math.cos(ax);

  let x2 = x1 * Math.cos(ay) + z1 * Math.sin(ay);
  let y2 = y1;
  let z2 = -x1 * Math.sin(ay) + z1 * Math.cos(ay);

  const x3 = x2 * Math.cos(az) - y2 * Math.sin(az);
  const y3 = x2 * Math.sin(az) + y2 * Math.cos(az);
  const z3 = z2;

  return [x3, y3, z3];
}

function project([x, y, z], w, h, fov = 420) {
  const scale = fov / (fov + z * 28);
  return {
    x: w / 2 + x * 42 * scale,
    y: h / 2 + y * 42 * scale,
    z,
    scale,
  };
}

function parseAccent(accent) {
  if (!accent || !accent.startsWith("#") || accent.length < 7) return [45, 212, 168];
  const r = parseInt(accent.slice(1, 3), 16);
  const g = parseInt(accent.slice(3, 5), 16);
  const b = parseInt(accent.slice(5, 7), 16);
  return [r, g, b];
}

export default function WireframeCanvas({
  className = "",
  accent = "#2dd4a8",
  size = 160,
  speed = 1,
  inner = true,
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;

    const ctx = canvas.getContext("2d");
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    ctx.scale(dpr, dpr);

    const [r, g, b] = parseAccent(accent);
    let raf = 0;
    let t0 = performance.now();

    const draw = (now) => {
      const t = ((now - t0) / 1000) * speed;
      ctx.clearRect(0, 0, size, size);

      const layers = inner
        ? [{ scale: 1, alpha: 1, offset: 0 }, { scale: 0.55, alpha: 0.45, offset: Math.PI * 0.5 }]
        : [{ scale: 1, alpha: 1, offset: 0 }];

      layers.forEach((layer) => {
        const projected = VERTICES.map((v) => {
          const scaled = v.map((c) => c * layer.scale);
          const rotated = rotatePoint(scaled, t * 0.7 + layer.offset, t * 0.9, t * 0.5 + layer.offset);
          return project(rotated, size, size);
        });

        EDGES.forEach(([a, bIdx]) => {
          const p1 = projected[a];
          const p2 = projected[bIdx];
          const depth = (p1.z + p2.z) / 2;
          const fade = 0.35 + ((depth + 1.5) / 3) * 0.65;

          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${fade * layer.alpha})`;
          ctx.lineWidth = a === 8 || bIdx === 8 ? 1.2 : 0.9;
          ctx.shadowColor = `rgba(${r}, ${g}, ${b}, 0.6)`;
          ctx.shadowBlur = 6;
          ctx.stroke();
        });

        projected.forEach((p, i) => {
          if (i === 8) {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 3 * p.scale, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${0.9 * layer.alpha})`;
            ctx.shadowBlur = 12;
            ctx.fill();
          }
        });
      });

      ctx.shadowBlur = 0;
      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [accent, size, speed, inner]);

  return (
    <canvas
      ref={canvasRef}
      className={`wireframe-canvas${className ? ` ${className}` : ""}`}
      aria-hidden="true"
    />
  );
}
