import ParticleField from "./ParticleField.jsx";

/**
 * Global portfolio atmosphere.
 * Kept intentionally low-contrast so the UI stays readable while the page
 * never feels like a flat black canvas.
 */
export default function SiteAtmosphere() {
  return (
    <div className="site-atmosphere" aria-hidden="true">
      <div className="site-atmosphere__grid" />
      <div className="site-atmosphere__aurora site-atmosphere__aurora--a" />
      <div className="site-atmosphere__aurora site-atmosphere__aurora--b" />
      <div className="site-atmosphere__aurora site-atmosphere__aurora--c" />
      <ParticleField
        className="site-atmosphere__particles"
        density="low"
        accent="#2dd4a8"
        accent2="#38bdf8"
      />
      <div className="site-atmosphere__signal" />
      <div className="site-atmosphere__scan" />
      <div className="site-atmosphere__vignette" />
    </div>
  );
}
