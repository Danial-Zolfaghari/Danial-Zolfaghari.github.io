import HoloGrid from "./HoloGrid.jsx";
import ParticleField from "./ParticleField.jsx";

const PRESETS = {
  preloader: { holo: true, particles: true, density: "medium", holoOpacity: 0.52 },
  hero: { holo: true, particles: true, density: "medium", holoOpacity: 0.58 },
  page: { holo: true, particles: true, density: "medium", holoOpacity: 0.48 },
  card: { holo: false, particles: false, density: "low", holoOpacity: 0 },
  section: { holo: true, particles: false, density: "low", holoOpacity: 0.22 },
};

/** Full-bleed background motion — holo floor + particles only (no wireframe boxes) */
export default function SceneBackdrop({ variant = "section", accent = "#2dd4a8", className = "" }) {
  const cfg = PRESETS[variant] || PRESETS.section;

  return (
    <div
      className={`scene-backdrop scene-backdrop--${variant}${className ? ` ${className}` : ""}`}
      style={{ "--scene-accent": accent, "--scene-holo-opacity": cfg.holoOpacity }}
      aria-hidden="true"
    >
      {cfg.holo && <HoloGrid compact={variant === "card"} className="scene-backdrop-holo" />}
      {cfg.particles && (
        <ParticleField
          className="scene-backdrop-particles"
          density={cfg.density}
          accent={accent}
          accent2={accent}
        />
      )}
      <div className="scene-backdrop-vignette" />
    </div>
  );
}
