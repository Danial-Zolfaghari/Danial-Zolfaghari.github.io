/** Subtle full-bleed background motion — accent stays minimal, no boxed widgets */
export default function AmbientBackdrop({ variant = "default", className = "" }) {
  return (
    <div
      className={`ambient-backdrop ambient-backdrop--${variant}${className ? ` ${className}` : ""}`}
      aria-hidden="true"
    >
      <div className="ambient-blob ambient-blob--a" />
      <div className="ambient-blob ambient-blob--b" />
    </div>
  );
}
