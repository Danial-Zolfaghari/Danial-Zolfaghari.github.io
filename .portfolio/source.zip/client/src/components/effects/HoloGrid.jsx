/** Perspective holographic floor grid */
export default function HoloGrid({ className = "", compact = false }) {
  return (
    <div className={`holo-grid${compact ? " holo-grid--compact" : ""}${className ? ` ${className}` : ""}`} aria-hidden="true">
      <div className="holo-grid-plane" />
      <div className="holo-grid-scan" />
      <div className="holo-grid-glow" />
    </div>
  );
}
