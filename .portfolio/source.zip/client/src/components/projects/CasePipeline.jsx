export default function CasePipeline({ steps = [] }) {
  if (!steps.length) return null;

  return (
    <div className="case-pipeline">
      {steps.map((step, i) => (
        <div key={step.step} className="case-pipeline-step glass-card" style={{ "--i": i }}>
          <div className="case-pipeline-marker">
            <span>{step.step}</span>
            {i < steps.length - 1 && <div className="case-pipeline-line" aria-hidden="true" />}
          </div>
          <div className="case-pipeline-body">
            <h4>{step.title}</h4>
            <p>{step.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
