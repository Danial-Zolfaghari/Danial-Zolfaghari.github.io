import { Link } from "react-router-dom";
import { FaArrowRight, FaRocket, FaServer } from "react-icons/fa6";
import SectionHead from "../SectionHead.jsx";
import ProjectCard from "./ProjectCard.jsx";
import { useReveal } from "../../hooks/useReveal.js";
import { getTopPicks } from "../../utils/projectHelpers.js";

export default function ProjectsTeaser({ catalog, projects }) {
  const { ref, visible } = useReveal();
  const selected = getTopPicks(projects).slice(0, 3);

  return (
    <section className="section section--teaser" id="work">
      <div className="container">
        <SectionHead
          num="03"
          title={catalog?.title || "Selected Work"}
          subtitle={catalog?.subtitle || "A curated selection — not a repository dump"}
          icon={FaRocket}
        />

        <p className="teaser-intro">
          {catalog?.description || "A small selection of systems that best represent my current engineering work."}
        </p>

        <div ref={ref} className={`teaser-sections${visible ? " reveal--visible" : " reveal"}`}>
          <div className="teaser-group">
            <h3 className="teaser-group-label">
              <FaRocket /> Current engineering focus
            </h3>
            <div className="teaser-grid teaser-grid--three">
              {selected.map((project, index) => (
                <ProjectCard key={project.slug || project.name} project={project} index={index} layout="teaser" />
              ))}
            </div>
          </div>

          <div className="teaser-cta glass-card">
            <FaServer className="teaser-cta-icon" />
            <span className="teaser-cta-num">7Y</span>
            <h3>FiveM engineering foundation</h3>
            <p>
              Seven years of Lua/JavaScript, MySQL, administration, authentication, logging, economy systems,
              production debugging, and performance work shaped how I approach live systems today.
            </p>
            <div className="teaser-cta-actions">
              <Link to="/foundation" className="btn btn-ghost">
                Read the foundation story <FaArrowRight />
              </Link>
              <Link to="/work" className="btn btn-primary">
                View selected work <FaArrowRight />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
