import { Link } from "react-router-dom";
import { FaArrowRight, FaRocket, FaStar } from "react-icons/fa6";
import SectionHead from "../SectionHead.jsx";
import ProjectCard from "./ProjectCard.jsx";
import { useReveal } from "../../hooks/useReveal.js";
import { getTopPicks } from "../../utils/projectHelpers.js";

export default function ProjectsTeaser({ catalog, projects }) {
  const { ref, visible } = useReveal();
  const razhmanTop = getTopPicks(projects, "Razhman");
  const fivemTop = getTopPicks(projects, "FiveM");
  const totalTop = getTopPicks(projects).length;

  return (
    <section className="section section--teaser" id="work">
      <div className="container">
        <SectionHead
          num="06"
          title={catalog?.title || "Selected Work"}
          subtitle={catalog?.subtitle || "Top picks — Razhman & FiveM"}
          icon={FaRocket}
        />

        <p className="teaser-intro">
          {catalog?.description || "Six flagship systems — three from Razhman and three from the FiveM foundation."}
        </p>

        <div ref={ref} className={`teaser-sections${visible ? " reveal--visible" : " reveal"}`}>
          <div className="teaser-group">
            <h3 className="teaser-group-label">
              <FaStar /> Top 3 · Razhman
            </h3>
            <div className="teaser-grid teaser-grid--three">
              {razhmanTop.map((p, i) => (
                <ProjectCard key={p.slug || p.name} project={p} index={i} layout="teaser" />
              ))}
            </div>
          </div>

          <div className="teaser-cta glass-card">
            <FaRocket className="teaser-cta-icon" />
            <span className="teaser-cta-num">{String(totalTop).padStart(2, "0")}</span>
            <h3>Top picks · FiveM foundation</h3>
            <p>
              {fivemTop.map((p) => p.name).join(", ")} — three more flagship systems from seven years of multiplayer backend work.
            </p>
            <div className="teaser-cta-actions">
              <Link to="/work?category=FiveM" className="btn btn-ghost">
                FiveM top 3 <FaArrowRight />
              </Link>
              <Link to="/work" className="btn btn-primary">
                View all top picks <FaArrowRight />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
