import { Link } from "react-router-dom";
import { FaArrowRight, FaStar } from "react-icons/fa6";
import { TechIcon } from "../../utils/techIcons.jsx";
import { getProjectSlug } from "../../utils/projectHelpers.js";
import ProjectVisual from "../visuals/ProjectVisual.jsx";
import SystemName from "../SystemName.jsx";

export default function ProjectCard({ project, index, layout = "grid" }) {
  const slug = getProjectSlug(project);
  const metrics = project.metrics?.slice(0, 3) || [];

  return (
    <article
      className={`showcase-card glass-card showcase-card--${layout}`}
      style={{ "--accent": project.accent || "#34d399", "--i": index }}
    >
      <div className="showcase-card-visual">
        <ProjectVisual project={project} compact />
      </div>

      <div className="showcase-card-glow" aria-hidden="true" />

      <div className="showcase-card-body">
        <div className="showcase-card-top">
          <span className="showcase-card-index">{String(index + 1).padStart(2, "0")}</span>
          <div className="showcase-card-badges">
            {project.topPick && (
              <span className="showcase-badge showcase-badge--featured">
                <FaStar /> Top pick
              </span>
            )}
            {project.segment && (
              <span className={`showcase-badge showcase-badge--segment showcase-badge--${project.segment.toLowerCase()}`}>
                {project.segment}
              </span>
            )}
            {project.status && (
              <span className="showcase-badge showcase-badge--status">{project.status}</span>
            )}
            {project.category && (
              <span className="showcase-badge showcase-badge--cat">{project.category}</span>
            )}
          </div>
        </div>

        {project.tagline && <p className="showcase-card-tagline">{project.tagline}</p>}

        <SystemName
          name={project.name}
          expansion={project.expansion}
          as="h2"
          className="showcase-card-title-wrap"
        />
        {project.subtitle && <p className="showcase-card-subtitle">{project.subtitle}</p>}
        <p className="showcase-card-summary">{project.summary || project.description}</p>

        {metrics.length > 0 && (
          <div className="showcase-card-metrics">
            {metrics.map((m) => (
              <div key={m.label} className="showcase-metric">
                <strong>{m.value ?? m}</strong>
                <span>{m.label ?? ""}</span>
              </div>
            ))}
          </div>
        )}

        <div className="showcase-card-tech">
          {project.technologies?.slice(0, 5).map((t) => (
            <span key={t}><TechIcon name={t} size={12} /> {t}</span>
          ))}
          {(project.technologies?.length || 0) > 5 && (
            <span className="showcase-tech-more">+{project.technologies.length - 5}</span>
          )}
        </div>

        <div className="showcase-card-footer">
          <span className="showcase-card-role">
            {project.role}
            {project.company && <> · {project.company}</>}
          </span>
          {project.year && <span className="showcase-card-year">{project.year}</span>}
          <Link to={`/work/${slug}`} className="showcase-card-link">
            View case study <FaArrowRight />
          </Link>
        </div>
      </div>
    </article>
  );
}
