export default function SectionHead({ num, title, subtitle, icon: Icon }) {
  return (
    <header className="section-head">
      <div className="section-head-meta">
        <span className="section-num">{num}</span>
        {subtitle && <span className="section-sub">{subtitle}</span>}
      </div>
      <div className="section-title-row">
        {Icon && <Icon className="section-icon" aria-hidden="true" />}
        <h2 className="section-title">{title}</h2>
      </div>
    </header>
  );
}
