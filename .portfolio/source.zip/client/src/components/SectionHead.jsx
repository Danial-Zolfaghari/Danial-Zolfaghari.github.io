export default function SectionHead({ num, title, subtitle, icon: Icon }) {
  return (
    <header className="section-head">
      <div className="section-head-left">
        {Icon && (
          <div className="section-icon">
            <Icon />
          </div>
        )}
        <span className="section-num">{num}</span>
      </div>
      <div>
        {subtitle && <p className="section-sub">{subtitle}</p>}
        <h2 className="section-title">{title}</h2>
      </div>
      <span className="section-line" />
    </header>
  );
}
