import { FaCompass, FaRocket, FaArrowsRotate, FaRoute } from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import ApproachFlowVisual from "./visuals/ApproachFlowVisual.jsx";
import { useReveal } from "../hooks/useReveal.js";

const STEP_ICONS = [FaCompass, FaRocket, FaArrowsRotate];

export default function Approach({ steps }) {
  const { ref, visible } = useReveal();

  return (
    <section className="section section--alt section--approach" id="approach">
      <div className="container">
        <SectionHead num="03" title="How I Work" subtitle="Personal process — not a tool list" icon={FaRoute} />
        <div ref={ref} className={`approach-layout${visible ? " reveal--visible" : " reveal"}`}>
          <div className="approach-visual-wrap glass-card">
            <ApproachFlowVisual steps={steps} active={visible} />
            <p className="approach-visual-caption">
              A continuous cycle — each release informs the next iteration.
            </p>
          </div>

          <div className="approach-grid">
            {steps?.map((s, i) => {
              const Icon = STEP_ICONS[i] || FaRocket;
              return (
                <article key={s.step} className="approach-card" style={{ "--i": i }}>
                  <div className="approach-icon"><Icon /></div>
                  <span className="approach-step">{s.step}</span>
                  <h3>{s.title}</h3>
                  <p>{s.text}</p>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
