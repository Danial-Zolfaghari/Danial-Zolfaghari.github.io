import {
  FaBriefcase, FaLocationDot, FaGraduationCap, FaUser,
  FaShieldHalved, FaCode, FaBrain, FaServer,
} from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";

const FOCUS = [
  { label: "Security Operations", Icon: FaShieldHalved },
  { label: "Backend Engineering", Icon: FaCode },
  { label: "AI / ML Systems", Icon: FaBrain },
  { label: "Infrastructure", Icon: FaServer },
];

export default function About({ profile }) {
  const { ref, visible } = useReveal();

  return (
    <section className="section" id="about">
      <div className="container">
        <SectionHead num="01" title="About Me" subtitle="Identity & focus" icon={FaUser} />
        <div ref={ref} className={`about-bento${visible ? " reveal--visible" : " reveal"}`}>
          <div className="about-main glass-card">
            <div className="about-main-icon" aria-hidden="true">
              <FaUser />
            </div>
            <p className="about-lead">{profile.summary}</p>
            {profile.mindset && (
              <p className="about-mindset">{profile.mindset}</p>
            )}
            <div className="about-tags">
              {FOCUS.map(({ label, Icon }) => (
                <span key={label}>
                  <Icon className="about-tag-icon" />
                  {label}
                </span>
              ))}
            </div>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaBriefcase /></div>
            <span className="card-label">Current Role</span>
            <strong>{profile.title}</strong>
            <p className="card-sub">{profile.company || "Razhman"} · Full-time</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaLocationDot /></div>
            <span className="card-label">Location</span>
            <strong>{profile.city}, {profile.country}</strong>
            <p className="card-sub">Remote-friendly · GMT+3:30</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaShieldHalved /></div>
            <span className="card-label">Core Focus</span>
            <strong>Security Operations & Backend Engineering</strong>
            <p className="card-sub">Network analysis · Observability · Applied AI</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaGraduationCap /></div>
            <span className="card-label">Education</span>
            <strong>{profile.education?.[0]?.title || "B.Sc. Computer Engineering"}</strong>
            <p className="card-sub">
              {profile.education?.[0]?.school || "Islamic Azad University, Pishva Branch"}
              {" · "}
              {profile.education?.[0]?.date || "In Progress"}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
