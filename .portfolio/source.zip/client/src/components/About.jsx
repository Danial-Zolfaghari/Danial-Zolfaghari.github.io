import {
  FaBriefcase, FaGraduationCap, FaUser,
  FaShieldHalved, FaCode, FaBrain, FaServer, FaDiagramProject,
} from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";

const FOCUS = [
  { label: "Security Operations", Icon: FaShieldHalved },
  { label: "Network Analysis", Icon: FaServer },
  { label: "Backend Engineering", Icon: FaCode },
  { label: "AI & Data Systems", Icon: FaBrain },
];

export default function About({ profile }) {
  const { ref, visible } = useReveal();

  return (
    <section className="section" id="about">
      <div className="container">
        <SectionHead num="01" title="About" subtitle="Engineering profile" icon={FaUser} />
        <div ref={ref} className={`about-bento${visible ? " reveal--visible" : " reveal"}`}>
          <div className="about-main glass-card">
            <p className="about-lead">{profile.summary}</p>
            {profile.mindset && <p className="about-mindset">{profile.mindset}</p>}
            <div className="about-tags">
              {FOCUS.map(({ label, Icon }) => (
                <span key={label}><Icon className="about-tag-icon" />{label}</span>
              ))}
            </div>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaBriefcase /></div>
            <span className="card-label">Current role</span>
            <strong>{profile.title}</strong>
            <p className="card-sub">{profile.company || "Razhman"} · Full-time</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaShieldHalved /></div>
            <span className="card-label">Operational scope</span>
            <strong>IRT · EOC · SOC / NOC</strong>
            <p className="card-sub">Incident response, DDoS, traffic analysis, firewall operations</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaDiagramProject /></div>
            <span className="card-label">Engineering scope</span>
            <strong>Backend · Observability · AI/Data</strong>
            <p className="card-sub">Internal platforms, automation, data systems, operational tooling</p>
          </div>

          <div className="about-card glass-card">
            <div className="about-card-icon"><FaGraduationCap /></div>
            <span className="card-label">Education</span>
            <strong>{profile.education?.[0]?.title || "B.Sc. Computer Engineering"}</strong>
            <p className="card-sub">
              {profile.education?.[0]?.school || "Islamic Azad University — Pishva Branch"}
              {" · "}
              {profile.education?.[0]?.date || "In Progress"}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
