import {
  FaEnvelope, FaCopy, FaCheck,
  FaShieldHalved, FaLayerGroup, FaComments,
} from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";
import { useCopy } from "../hooks/useCopy.js";

export default function Contact({ profile }) {
  const { ref, visible } = useReveal();
  const { copy, copied } = useCopy();

  return (
    <section className="section section--contact" id="contact">
      <div className="container">
        <SectionHead num="08" title="Let's Connect" subtitle="Engineering conversations" icon={FaComments} />
        <div ref={ref} className={`contact-grid${visible ? " reveal--visible" : " reveal"}`}>
          <div className="contact-intro">
            <h3>Security, backend, observability, or applied AI?</h3>
            <p>
              For technical conversations, collaboration, or opportunities around security engineering,
              backend systems, network analysis, observability, and AI/data platforms, email is the cleanest path.
            </p>
            <div className="contact-trust">
              <span><FaShieldHalved /> Production security operations</span>
              <span><FaLayerGroup /> Backend & data systems</span>
              <span><FaComments /> Direct technical conversation</span>
            </div>
          </div>

          <div className="contact-actions">
            {profile.email && (
              <div className="contact-card glass-card">
                <FaEnvelope className="contact-icon" />
                <div className="contact-card-body">
                  <span className="card-label">Email</span>
                  <strong>{profile.email}</strong>
                </div>
                <div className="contact-card-btns">
                  <a href={`mailto:${profile.email}`} className="btn btn-primary btn-sm">Send email</a>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => copy(profile.email, "email")}
                  >
                    {copied === "email" ? <FaCheck /> : <FaCopy />}
                    {copied === "email" ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
