import {
  FaEnvelope, FaPhone, FaLocationDot, FaCopy, FaCheck,
  FaShieldHalved, FaCertificate, FaLayerGroup, FaComments,
} from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";
import { useCopy } from "../hooks/useCopy.js";

export default function Contact({ profile }) {
  const location = [profile.city, profile.country].filter(Boolean).join(", ");
  const { ref, visible } = useReveal();
  const { copy, copied } = useCopy();

  return (
    <section className="section section--contact" id="contact">
      <div className="container">
        <SectionHead num="08" title="Let's Connect" subtitle="Start here" icon={FaComments} />
        <div ref={ref} className={`contact-grid${visible ? " reveal--visible" : " reveal"}`}>
          <div className="contact-intro">
            <h3>Ready to build something resilient?</h3>
            <p>
              I'm open to security engineering, backend development, and infrastructure roles.
              The fastest path to a conversation is email — I typically respond within 24 hours.
            </p>
            <div className="contact-trust">
              <span><FaShieldHalved /> Production experience</span>
              <span><FaCertificate /> Security certified</span>
              <span><FaLayerGroup /> Full-stack capable</span>
            </div>
          </div>

          <div className="contact-actions">
            {profile.email && (
              <div className="contact-card glass-card">
                <FaEnvelope className="contact-icon" />
                <div className="contact-card-body">
                  <span className="card-label">Email — fastest response</span>
                  <strong>{profile.email}</strong>
                </div>
                <div className="contact-card-btns">
                  <a href={`mailto:${profile.email}`} className="btn btn-primary btn-sm">Send email</a>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => copy(profile.email, "email")}
                  >
                    {copied === "email" ? <FaCheck /> : <FaCopy />}
                    {copied === "email" ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>
            )}

            {profile.phone && (
              <div className="contact-card glass-card">
                <FaPhone className="contact-icon" />
                <div className="contact-card-body">
                  <span className="card-label">Phone</span>
                  <strong>{profile.phone}</strong>
                </div>
                <div className="contact-card-btns">
                  <a href={`tel:${profile.phone}`} className="btn btn-ghost btn-sm">Call</a>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => copy(profile.phone, "phone")}
                  >
                    {copied === "phone" ? <FaCheck /> : <FaCopy />}
                  </button>
                </div>
              </div>
            )}

            {location && (
              <div className="contact-card glass-card contact-card--static">
                <FaLocationDot className="contact-icon" />
                <div className="contact-card-body">
                  <span className="card-label">Based in</span>
                  <strong>{location}</strong>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
