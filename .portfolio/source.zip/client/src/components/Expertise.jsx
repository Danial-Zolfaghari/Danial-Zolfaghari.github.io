import { FaBrain, FaCode, FaServer, FaShieldHalved, FaLayerGroup } from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";

const ICONS = {
  shield: FaShieldHalved,
  code: FaCode,
  brain: FaBrain,
  server: FaServer,
};

export default function Expertise({ items }) {
  const { ref, visible } = useReveal();

  return (
    <section className="section section--expertise" id="expertise">
      <div className="container">
        <SectionHead num="02" title="Core Expertise" subtitle="What I deliver" icon={FaLayerGroup} />
        <div ref={ref} className={`expertise-grid${visible ? " reveal--visible" : " reveal"}`}>
          {items?.map((item, i) => {
            const Icon = ICONS[item.icon] || FaCode;
            return (
              <article key={item.title} className="expertise-card" style={{ "--i": i }}>
                <div className="expertise-icon">
                  <Icon />
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
