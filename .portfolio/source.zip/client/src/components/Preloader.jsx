import { useEffect, useState } from "react";
import SceneBackdrop from "./effects/SceneBackdrop.jsx";

const DURATION_MS = 3400;
const HOLD_MS = 320;
const FADE_MS = 550;

const STATUS_LINES = [
  { at: 0, text: "Initializing experience" },
  { at: 38, text: "Loading portfolio assets" },
  { at: 72, text: "Preparing interface" },
  { at: 92, text: "Almost ready" },
];

export default function Preloader({ name, title, onDone }) {
  const [progress, setProgress] = useState(0);
  const [fade, setFade] = useState(false);
  const [statusIdx, setStatusIdx] = useState(0);

  const initial = name?.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "DZ";
  const displayName = name || "Danial Zolfaghari";
  const statusText = STATUS_LINES[statusIdx]?.text || STATUS_LINES[STATUS_LINES.length - 1].text;

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      onDone();
      return undefined;
    }

    const start = performance.now();
    let raf = 0;

    const tick = (now) => {
      const t = Math.min((now - start) / DURATION_MS, 1);
      const eased = 1 - (1 - t) ** 2.1;
      const pct = eased * 100;
      setProgress(pct);

      const line = [...STATUS_LINES].reverse().find((l) => pct >= l.at);
      if (line) setStatusIdx(STATUS_LINES.indexOf(line));

      if (t < 1) {
        raf = requestAnimationFrame(tick);
        return;
      }

      setProgress(100);
      setTimeout(() => {
        setFade(true);
        setTimeout(onDone, FADE_MS);
      }, HOLD_MS);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  const circumference = 2 * Math.PI * 46;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className={`preloader preloader--scene${fade ? " preloader--out" : ""}`}>
      <SceneBackdrop variant="preloader" />

      <div className="preloader-inner preloader-inner--scene">
        <div className="preloader-mark">
          <svg className="preloader-ring-svg" viewBox="0 0 104 104" aria-hidden="true">
            <circle cx="52" cy="52" r="46" className="preloader-ring-bg" />
            <circle
              cx="52"
              cy="52"
              r="46"
              className="preloader-ring-progress"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
            />
          </svg>
          <div className="preloader-logo-core preloader-logo-core--scene">
            <span>{initial}</span>
          </div>
        </div>

        <p className="preloader-brand">{displayName}</p>
        {title && <p className="preloader-role">{title}</p>}

        <p className="preloader-status" key={statusText}>{statusText}</p>

        <div className="preloader-progress-row">
          <div className="preloader-bar preloader-bar--scene">
            <div className="preloader-fill" style={{ width: `${progress}%` }} />
          </div>
          <span className="preloader-pct">{Math.round(progress)}%</span>
        </div>
      </div>
    </div>
  );
}
