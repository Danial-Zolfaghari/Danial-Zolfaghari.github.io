import { useEffect, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { FaArrowLeft, FaBars, FaMagnifyingGlass, FaXmark } from "react-icons/fa6";
import { useScrollSpy } from "../hooks/useScrollSpy.js";
import { navigateToSection } from "../utils/scrollToSection.js";

function getBackLink(pathname) {
  if (pathname === "/") return null;
  if (pathname === "/foundation") return { to: "/", label: "Home" };
  if (pathname === "/work") return { to: "/", label: "Portfolio" };
  if (pathname.startsWith("/work/")) return { to: "/work", label: "Projects" };
  return { to: "/", label: "Home" };
}

const HOME_LINKS = [
  { id: "about", label: "About" },
  { id: "expertise", label: "Expertise" },
  { to: "/work", id: "work", label: "Work", route: true },
  { id: "experience", label: "Experience" },
  { id: "contact", label: "Contact" },
];

export default function Navbar({ name, onCommandOpen, onContactOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === "/";
  const backLink = getBackLink(location.pathname);
  const activeSection = useScrollSpy(HOME_LINKS.filter((l) => !l.route).map((l) => l.id), 120);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    const desktop = window.matchMedia("(min-width: 1081px)");
    const closeOnDesktop = (event) => {
      if (event.matches) setOpen(false);
    };
    desktop.addEventListener?.("change", closeOnDesktop);
    return () => desktop.removeEventListener?.("change", closeOnDesktop);
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  const initial = name?.split(" ").map((word) => word[0]).join("").slice(0, 2).toUpperCase() || "DZ";

  const handleSectionClick = (event, sectionId) => {
    event.preventDefault();
    setOpen(false);
    navigateToSection(navigate, location.pathname, sectionId);
  };

  const renderLinks = (mobile = false) => HOME_LINKS.map((link, index) => {
    const content = mobile ? (
      <>
        <span className="nav-mobile-index">{String(index + 1).padStart(2, "0")}</span>
        <span>{link.label}</span>
      </>
    ) : link.label;

    if (link.route) {
      return (
        <NavLink
          key={link.to}
          to={link.to}
          className={({ isActive }) => isActive ? "active" : ""}
          onClick={() => setOpen(false)}
        >
          {content}
        </NavLink>
      );
    }

    return (
      <a
        key={link.id}
        href={`/#${link.id}`}
        className={isHome && activeSection === link.id ? "active" : ""}
        onClick={(event) => handleSectionClick(event, link.id)}
      >
        {content}
      </a>
    );
  });

  return (
    <>
      <header className={`nav${scrolled ? " nav--scrolled" : ""}`}>
        <div className="container nav-inner">
          <div className="nav-left">
            {backLink && (
              <Link to={backLink.to} className="nav-back" aria-label={`Back to ${backLink.label}`}>
                <FaArrowLeft />
              </Link>
            )}
            <Link to="/" className="nav-brand" onClick={() => setOpen(false)}>
              <span className="nav-logo">{initial}</span>
              <span className="nav-brand-copy">
                <strong>{name}</strong>
                <small>IRT / EOC · Security · Backend</small>
              </span>
            </Link>
          </div>

          <nav className="nav-links nav-links--desktop" aria-label="Main navigation">
            {renderLinks(false)}
          </nav>

          <div className="nav-actions">
            <button type="button" className="nav-search" onClick={onCommandOpen} aria-label="Open quick search">
              <FaMagnifyingGlass />
              <span>Search</span>
              <kbd>Ctrl K</kbd>
            </button>
            <button type="button" className="nav-cta" onClick={onContactOpen}>Let&apos;s talk</button>
            <button
              type="button"
              className={`nav-toggle${open ? " open" : ""}`}
              onClick={() => setOpen((value) => !value)}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls="mobile-navigation"
            >
              {open ? <FaXmark /> : <FaBars />}
            </button>
          </div>
        </div>
      </header>

      {open && (
        <>
          <button
            type="button"
            className="nav-mobile-overlay"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
          />
          <nav id="mobile-navigation" className="nav-mobile-menu" aria-label="Mobile navigation">
            <div className="nav-mobile-menu-head">
              <span>Navigation</span>
              <small>Portfolio / 2026</small>
            </div>
            <div className="nav-mobile-menu-links">
              {renderLinks(true)}
            </div>
            <button
              type="button"
              className="nav-mobile-contact"
              onClick={() => {
                setOpen(false);
                onContactOpen?.();
              }}
            >
              <span>Start a conversation</span>
              <span aria-hidden="true">↗</span>
            </button>
          </nav>
        </>
      )}
    </>
  );
}
