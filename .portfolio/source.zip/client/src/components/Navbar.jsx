import { useEffect, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { FaArrowLeft, FaMagnifyingGlass } from "react-icons/fa6";
import { useScrollSpy } from "../hooks/useScrollSpy.js";
import { navigateToSection } from "../utils/scrollToSection.js";

function getBackLink(pathname) {
  if (pathname === "/") return null;
  if (pathname === "/foundation") return { to: "/", label: "Back to home" };
  if (pathname === "/work") return { to: "/", label: "Back to portfolio" };
  if (pathname.startsWith("/work/")) return { to: "/work", label: "Back to projects" };
  return { to: "/", label: "Back to home" };
}

const HOME_LINKS = [
  { id: "about", label: "About" },
  { id: "expertise", label: "Expertise" },
  { id: "skills", label: "Skills" },
  { to: "/work", id: "work", label: "Projects", route: true },
  { id: "contact", label: "Contact" },
];

export default function Navbar({ name, onCommandOpen, onContactOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === "/";
  const backLink = getBackLink(location.pathname);
  const activeSection = useScrollSpy(
    HOME_LINKS.filter((l) => !l.route).map((l) => l.id),
    120
  );

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const initial = name?.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "DZ";

  const isActive = (link) => {
    if (link.route) return location.pathname.startsWith("/work");
    if (!isHome) return false;
    return activeSection === link.id;
  };

  const handleSectionClick = (e, sectionId) => {
    e.preventDefault();
    setOpen(false);
    navigateToSection(navigate, location.pathname, sectionId);
  };

  const handleLetsTalk = (e) => {
    e.preventDefault();
    setOpen(false);
    onContactOpen?.();
  };

  return (
    <header className={`nav${scrolled ? " nav--scrolled" : ""}`}>
      <div className={`nav-inner container${backLink ? " nav-inner--sub" : ""}`}>
        <div className="nav-left">
          {backLink && (
            <Link to={backLink.to} className="nav-back" onClick={() => setOpen(false)}>
              <FaArrowLeft aria-hidden="true" />
              <span className="nav-back-label">{backLink.label}</span>
            </Link>
          )}
          <Link to="/" className="nav-brand" onClick={() => setOpen(false)}>
            <span className="nav-logo">{initial}</span>
            <span className="nav-name">{name?.split(" ")[0]}</span>
          </Link>
        </div>

        <nav className={`nav-links${open ? " open" : ""}`} aria-label="Main">
          {HOME_LINKS.map((l) =>
            l.route ? (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive: active }) => (active ? "active" : "")}
                onClick={() => setOpen(false)}
              >
                {l.label}
              </NavLink>
            ) : (
              <a
                key={l.id}
                href={`/#${l.id}`}
                className={isActive(l) ? "active" : ""}
                onClick={(e) => handleSectionClick(e, l.id)}
              >
                {l.label}
              </a>
            )
          )}
        </nav>

        <button type="button" className="nav-search" onClick={onCommandOpen} aria-label="Open command palette">
          <FaMagnifyingGlass />
          <span>Search</span>
          <kbd>Ctrl K</kbd>
        </button>

        <button type="button" className="nav-cta" onClick={handleLetsTalk}>
          Let&apos;s talk
        </button>

        <button
          type="button"
          className={`nav-toggle${open ? " open" : ""}`}
          onClick={() => setOpen(!open)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          <span /><span /><span />
        </button>
      </div>

      {open && <div className="nav-overlay" onClick={() => setOpen(false)} aria-hidden="true" />}
    </header>
  );
}
