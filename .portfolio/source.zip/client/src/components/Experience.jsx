import { useState } from "react";
import { FaChevronDown, FaClockRotateLeft, FaArrowRight } from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";
import { HighlightedText } from "../utils/highlightText.jsx";

export default function Experience({ jobs }) {
  const [open, setOpen] = useState(0);
  const { ref, visible } = useReveal();

  return (
    <section className="section" id="experience">
      <div className="container">
        <SectionHead num="05" title="Experience" subtitle="Career trajectory" icon={FaClockRotateLeft} />
        <div ref={ref} className={`timeline${visible ? " reveal--visible" : " reveal"}`}>
          {jobs?.map((job, i) => {
            const expanded = open === i;
            return (
              <article
                key={i}
                className={`timeline-item${expanded ? " expanded" : ""}${job.highlight ? " timeline-item--foundation" : ""}`}
              >
                <button
                  type="button"
                  className="timeline-trigger"
                  onClick={() => setOpen(expanded ? -1 : i)}
                  aria-expanded={expanded}
                >
                  <div className="timeline-marker">
                    <span className="timeline-dot" />
                  </div>
                  <div className="timeline-summary">
                    <div>
                      <h3>{job.position}</h3>
                      <p className="company">{job.company}</p>
                    </div>
                    <div className="timeline-meta">
                      {job.type && <span className="timeline-type">{job.type}</span>}
                      <time>{job.date}</time>
                      <FaChevronDown className="timeline-chevron" />
                    </div>
                  </div>
                </button>

                <div className={`timeline-panel${expanded ? " timeline-panel--open" : ""}`} aria-hidden={!expanded}>
                  <div className="timeline-panel-inner">
                    <div className="timeline-body glass-card">
                      <ul>
                        {job.description?.map((line, j) => (
                          <li key={j} style={{ "--line-i": j }}>
                            <HighlightedText text={line} />
                          </li>
                        ))}
                      </ul>
                      {job.highlight && (
                        <a href="/foundation" className="timeline-foundation-link">
                          Full engineering foundation story <FaArrowRight />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
