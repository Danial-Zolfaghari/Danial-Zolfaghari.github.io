import { useEffect, useRef, useState } from "react";

const TEXT_SELECTOR = "input, textarea, [contenteditable='true']";

const INTERACTIVE_SELECTOR = [
  "a",
  "button",
  "input",
  "textarea",
  "select",
  "summary",
  "[role='button']",
  "[data-cursor='interactive']",
].join(",");

export default function CustomCursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    const sync = () => setEnabled(finePointer.matches && !reducedMotion.matches);
    sync();

    finePointer.addEventListener?.("change", sync);
    reducedMotion.addEventListener?.("change", sync);
    return () => {
      finePointer.removeEventListener?.("change", sync);
      reducedMotion.removeEventListener?.("change", sync);
    };
  }, []);

  useEffect(() => {
    if (!enabled) return undefined;

    const root = document.documentElement;
    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return undefined;

    root.classList.add("has-custom-cursor");

    let visible = false;
    let interactive = false;

    const setVisible = (nextVisible) => {
      if (visible === nextVisible) return;
      visible = nextVisible;
      dot.dataset.visible = String(nextVisible);
      ring.dataset.visible = String(nextVisible);
    };

    const setInteractive = (nextInteractive) => {
      if (interactive === nextInteractive) return;
      interactive = nextInteractive;
      dot.dataset.interactive = String(nextInteractive);
      ring.dataset.interactive = String(nextInteractive);
    };

    const move = (event) => {
      setVisible(true);
      const x = event.clientX;
      const y = event.clientY;
      dot.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      ring.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      const isTextTarget = Boolean(event.target?.closest?.(TEXT_SELECTOR));
      dot.dataset.text = String(isTextTarget);
      ring.dataset.text = String(isTextTarget);
      setInteractive(!isTextTarget && Boolean(event.target?.closest?.(INTERACTIVE_SELECTOR)));
    };

    const leave = () => setVisible(false);
    const enter = () => setVisible(true);
    const down = () => ring.dataset.pressed = "true";
    const up = () => ring.dataset.pressed = "false";

    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerdown", down, { passive: true });
    window.addEventListener("pointerup", up, { passive: true });
    document.documentElement.addEventListener("mouseleave", leave);
    document.documentElement.addEventListener("mouseenter", enter);

    return () => {
      root.classList.remove("has-custom-cursor");
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      document.documentElement.removeEventListener("mouseleave", leave);
      document.documentElement.removeEventListener("mouseenter", enter);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div className="custom-cursor" aria-hidden="true">
      <span ref={ringRef} className="custom-cursor-ring" data-visible="false" data-interactive="false" data-pressed="false" data-text="false" />
      <span ref={dotRef} className="custom-cursor-dot" data-visible="false" data-interactive="false" data-text="false" />
    </div>
  );
}
