import { useMemo, useState } from "react";
import SectionHead from "./SectionHead.jsx";
import SkillsDistribution from "./SkillsDistribution.jsx";
import { TechIcon } from "../utils/techIcons.jsx";
import { useReveal } from "../hooks/useReveal.js";
import { FaMagnifyingGlass, FaToolbox } from "react-icons/fa6";

const ACCENTS = ["#2dd4a8", "#34d399", "#10b981", "#059669", "#6ee7b7"];

export default function Skills({ skills }) {
  const [active, setActive] = useState("All");
  const [query, setQuery] = useState("");
  const { ref, visible } = useReveal();

  const categories = useMemo(
    () => ["All", ...(skills?.map((g) => g.category) || [])],
    [skills]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (skills || [])
      .filter((g) => active === "All" || g.category === active)
      .map((g) => ({
        ...g,
        items: g.items.filter((item) => !q || item.toLowerCase().includes(q)),
      }))
      .filter((g) => g.items.length > 0);
  }, [skills, active, query]);

  const totalCount = filtered.reduce((n, g) => n + g.items.length, 0);

  return (
    <section className="section section--alt" id="skills">
      <div className="container">
        <SectionHead num="06" title="Skills & Stack" subtitle="Interactive explorer" icon={FaToolbox} />

        <div className="skills-toolbar">
          <div className="skills-search">
            <FaMagnifyingGlass />
            <input
              type="search"
              placeholder="Filter technologies…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search skills"
            />
          </div>
          <div className="skills-tabs" role="tablist">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={active === cat}
                className={active === cat ? "active" : ""}
                onClick={() => setActive(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div ref={ref} className={`skills-layout${visible ? " reveal--visible" : " reveal"}`}>
          <SkillsDistribution skills={skills} visible={visible} />

          <div className="skills-main">
            <p className="skills-count">{totalCount} technologies shown</p>
            <div className="skills-grid">
              {filtered.map((group, i) => (
                <div
                  key={group.category}
                  className="skill-card glass-card"
                  style={{ "--accent": ACCENTS[i % ACCENTS.length], "--i": i }}
                >
                  <h3>{group.category}</h3>
                  <div className="skill-tags">
                    {group.items.map((item) => (
                      <span key={item} className="skill-tag">
                        <TechIcon name={item} size={13} />
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
