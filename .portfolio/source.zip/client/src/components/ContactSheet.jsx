import { useEffect } from "react";
import {
  FaXmark,
  FaEnvelope,
  FaPhone,
  FaLocationDot,
  FaCopy,
  FaCheck,
  FaShieldHalved,
  FaCertificate,
  FaLayerGroup,
} from "react-icons/fa6";
import { useCopy } from "../hooks/useCopy.js";

export default function ContactSheet({ open, onClose, profile }) {
  const { copy, copied } = useCopy();
  const location = [profile?.city, profile?.country].filter(Boolean).join(", ");

  useEffect(() => {
    if (!open) return undefined;

    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="contact-sheet" role="dialog" aria-modal="true" aria-labelledby="contact-sheet-title">
      <button type="button" className="contact-sheet-backdrop" onClick={onClose} aria-label="Close contact menu" />

      <div className="contact-sheet-panel glass-card">
        <button type="button" className="contact-sheet-close" onClick={onClose} aria-label="Close">
          <FaXmark />
        </button>

        <div className="contact-sheet-head">
          <p className="contact-sheet-label">Get in touch</p>
          <h2 id="contact-sheet-title">Let&apos;s talk</h2>
          <p className="contact-sheet-lead">
            {profile?.availability || "Open to opportunities"} — I typically respond within 24 hours.
          </p>
        </div>

        <div className="contact-sheet-trust">
          <span><FaShieldHalved /> Production experience</span>
          <span><FaCertificate /> Security certified</span>
          <span><FaLayerGroup /> Full-stack capable</span>
        </div>

        <div className="contact-sheet-cards">
          {profile?.email && (
            <div className="contact-sheet-row">
              <FaEnvelope className="contact-sheet-icon" />
              <div>
                <span className="card-label">Email</span>
                <strong>{profile.email}</strong>
              </div>
              <div className="contact-sheet-row-actions">
                <a href={`mailto:${profile.email}`} className="btn btn-primary btn-sm">Email</a>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => copy(profile.email, "sheet-email")}>
                  {copied === "sheet-email" ? <FaCheck /> : <FaCopy />}
                </button>
              </div>
            </div>
          )}

          {profile?.phone && (
            <div className="contact-sheet-row">
              <FaPhone className="contact-sheet-icon" />
              <div>
                <span className="card-label">Phone</span>
                <strong>{profile.phone}</strong>
              </div>
              <div className="contact-sheet-row-actions">
                <a href={`tel:${profile.phone}`} className="btn btn-ghost btn-sm">Call</a>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => copy(profile.phone, "sheet-phone")}>
                  {copied === "sheet-phone" ? <FaCheck /> : <FaCopy />}
                </button>
              </div>
            </div>
          )}

          {location && (
            <div className="contact-sheet-row contact-sheet-row--static">
              <FaLocationDot className="contact-sheet-icon" />
              <div>
                <span className="card-label">Based in</span>
                <strong>{location}</strong>
              </div>
            </div>
          )}
        </div>

        {profile?.title && (
          <p className="contact-sheet-foot">{profile.name} · {profile.title}</p>
        )}
      </div>
    </div>
  );
}
