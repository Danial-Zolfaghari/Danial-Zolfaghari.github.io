import {
  FaServer, FaUsersGear, FaCode, FaClock, FaCircleInfo, FaWrench, FaLayerGroup,
} from "react-icons/fa6";
import SectionHead from "./SectionHead.jsx";
import { useReveal } from "../hooks/useReveal.js";

const STAT_ICONS = [FaClock, FaUsersGear, FaServer];

export default function EngineeringFoundation({ foundation, fullPage = false }) {
  const { ref, visible } = useReveal();

  if (!foundation) return null;

  const stats = foundation.stats || [];
  const core = foundation.core;
  const capabilities = foundation.capabilities || [];

  return (
    <section className={`section section--foundation${fullPage ? " section--foundation-page" : ""}`} id={fullPage ? undefined : "foundation"}>
      <div className="container">
        <SectionHead
          num={fullPage ? "—" : "05+"}
          title={foundation.title || "Engineering Foundation"}
          subtitle={foundation.subtitle || "Seven years of backend before security became the headline"}
          icon={FaServer}
        />

        <div ref={ref} className={`foundation-spotlight${visible ? " reveal--visible" : " reveal"}`}>
          {foundation.whatIsFiveM && (
            <div className="foundation-about glass-card">
              <div className="foundation-about-head">
                <FaCircleInfo />
                <div>
                  <h4>What is FiveM?</h4>
                  <span>Context — not my current career focus</span>
                </div>
              </div>
              <p>{foundation.whatIsFiveM}</p>
            </div>
          )}

          {core && (
            <div className="foundation-core glass-card">
              <div className="foundation-core-head">
                <FaLayerGroup />
                <div>
                  <span className="foundation-core-label">Custom framework</span>
                  <h4>{core.title}</h4>
                  <p className="foundation-core-tag">{core.tagline}</p>
                </div>
              </div>
              <p className="foundation-core-desc">{core.description}</p>
              {core.comparesTo?.length > 0 && (
                <div className="foundation-core-compare">
                  <span>Instead of off-the-shelf:</span>
                  {core.comparesTo.map((c) => (
                    <span key={c} className="foundation-core-chip">{c}</span>
                  ))}
                </div>
              )}
              {core.highlights?.length > 0 && (
                <ul className="foundation-highlights foundation-highlights--compact">
                  {core.highlights.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <div className="foundation-hero glass-card">
            <div className="foundation-hero-top">
              <div className="foundation-brand">
                <span className="foundation-platform">{foundation.platform}</span>
                <h3>{foundation.role}</h3>
                <p>{foundation.period}</p>
              </div>
              <div className="foundation-stats">
                {stats.map((s, i) => {
                  const Icon = STAT_ICONS[i] || FaServer;
                  return (
                    <div key={s.label} className="foundation-stat">
                      <Icon aria-hidden="true" />
                      <strong>{s.value}</strong>
                      <span>{s.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <p className="foundation-summary">{foundation.summary}</p>

            {foundation.ecosystemNote && (
              <p className="foundation-ecosystem-note">{foundation.ecosystemNote}</p>
            )}

            {foundation.opsNote && (
              <p className="foundation-ops-note">
                <FaWrench aria-hidden="true" />
                {foundation.opsNote}
              </p>
            )}

            {foundation.stack?.length > 0 && (
              <div className="foundation-stack">
                {foundation.stack.map((t) => (
                  <span key={t}>{t}</span>
                ))}
              </div>
            )}
          </div>

          <div className="foundation-detail glass-card">
            <div className="foundation-detail-head">
              <FaCode />
              <div>
                <h4>What I built & operated</h4>
                <span>Production discipline that carries into security engineering today</span>
              </div>
            </div>
            <ul className="foundation-highlights">
              {(foundation.highlights || []).map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>

          {capabilities.length > 0 && (
            <div className="foundation-capabilities">
              <h4>{foundation.capabilitiesTitle || "Representative capabilities"}</h4>
              <p className="foundation-capabilities-sub">{foundation.capabilitiesSubtitle}</p>
              <div className="foundation-capabilities-grid">
                {capabilities.map((cap) => (
                  <article key={cap.title} className="foundation-cap glass-card">
                    <strong>{cap.title}</strong>
                    {cap.date && <time>Shipped {cap.date}</time>}
                    <p>{cap.text}</p>
                  </article>
                ))}
              </div>
            </div>
          )}

          {foundation.creativeTools && (
            <div className="foundation-creative glass-card">
              <div className="foundation-detail-head">
                <FaWrench />
                <div>
                  <h4>{foundation.creativeTools.title}</h4>
                  <span>{foundation.creativeTools.subtitle}</span>
                </div>
              </div>
              <div className="foundation-creative-grid">
                {foundation.creativeTools.groups?.map((group) => (
                  <div key={group.title} className="foundation-creative-group">
                    <strong>{group.title}</strong>
                    <div className="foundation-stack">
                      {group.items?.map((item) => (
                        <span key={item}>{item}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {foundation.bridge && (
            <p className="foundation-bridge">{foundation.bridge}</p>
          )}
        </div>
      </div>
    </section>
  );
}
