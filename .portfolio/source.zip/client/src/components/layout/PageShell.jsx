import { useState } from "react";
import { Outlet } from "react-router-dom";
import { useProfile } from "../../hooks/useProfile.js";
import { useCommandPalette } from "../../hooks/useCommandPalette.js";
import { useHashScroll } from "../../hooks/useHashScroll.js";
import ScrollProgress from "../ScrollProgress.jsx";
import CommandPalette from "../CommandPalette.jsx";
import ContactSheet from "../ContactSheet.jsx";
import Navbar from "../Navbar.jsx";
import Footer from "../Footer.jsx";
import BackToTop from "../BackToTop.jsx";
import CustomCursor from "../CustomCursor.jsx";
import SiteAtmosphere from "../effects/SiteAtmosphere.jsx";

export default function PageShell() {
  const { profile, loading } = useProfile();
  const [contactOpen, setContactOpen] = useState(false);
  const cmd = useCommandPalette();

  useHashScroll(!loading);

  if (loading) {
    return (
      <div className="loader-screen">
        <div className="loader-ring" />
        <p>Loading portfolio…</p>
      </div>
    );
  }

  const openContact = () => setContactOpen(true);
  const closeContact = () => setContactOpen(false);

  return (
    <>
      <a href="#main-content" className="skip-link">Skip to content</a>
      <SiteAtmosphere />
      <CustomCursor />
      <ScrollProgress />
      <CommandPalette
        open={cmd.open}
        onClose={cmd.close}
        skills={profile.skills}
        projects={profile.projects}
      />
      <ContactSheet open={contactOpen} onClose={closeContact} profile={profile} />
      <Navbar
        name={profile.name}
        onCommandOpen={cmd.toggle}
        onContactOpen={openContact}
      />
      <Outlet context={{ profile, openContact }} />
      <Footer name={profile.name} title={profile.title} />
      <BackToTop />
    </>
  );
}
