import { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { useProfile } from "../../hooks/useProfile.js";
import { useCommandPalette } from "../../hooks/useCommandPalette.js";
import { useHashScroll } from "../../hooks/useHashScroll.js";
import { isIntroDone, markIntroDone } from "../../utils/introSession.js";
import Preloader from "../Preloader.jsx";
import ScrollProgress from "../ScrollProgress.jsx";
import AmbientGlow from "../AmbientGlow.jsx";
import CommandPalette from "../CommandPalette.jsx";
import ContactSheet from "../ContactSheet.jsx";
import Navbar from "../Navbar.jsx";
import Footer from "../Footer.jsx";
import BackToTop from "../BackToTop.jsx";

export default function PageShell() {
  const { profile, loading } = useProfile();
  const location = useLocation();
  const isHome = location.pathname === "/";
  const introAlreadyDone = isIntroDone();

  const [introFinished, setIntroFinished] = useState(introAlreadyDone);
  const [contactOpen, setContactOpen] = useState(false);
  const showIntro = isHome && !introAlreadyDone && !introFinished;

  const cmd = useCommandPalette();
  const shellVisible = !showIntro;

  useHashScroll(shellVisible);

  const handleIntroDone = () => {
    markIntroDone();
    setIntroFinished(true);
  };

  const openContact = () => setContactOpen(true);
  const closeContact = () => setContactOpen(false);

  if (loading) {
    return (
      <div className="loader-screen">
        <div className="loader-ring" />
        <p>Initializing…</p>
      </div>
    );
  }

  return (
    <>
      {showIntro && (
        <Preloader
          name={profile.name}
          title={profile.title}
          onDone={handleIntroDone}
        />
      )}

      {shellVisible && (
        <>
          <a href={isHome ? "#about" : "/#about"} className="skip-link">Skip to content</a>
          <ScrollProgress />
          <AmbientGlow />
          <CommandPalette
            open={cmd.open}
            onClose={cmd.close}
            skills={profile.skills}
            projects={profile.projects}
          />
          <ContactSheet open={contactOpen} onClose={closeContact} profile={profile} />
          <Navbar
            name={profile.name}
            onCommandOpen={cmd.toggle}
            onContactOpen={openContact}
          />
          <Outlet context={{ profile, openContact }} />
          <Footer name={profile.name} title={profile.title} />
          <BackToTop />
        </>
      )}
    </>
  );
}
