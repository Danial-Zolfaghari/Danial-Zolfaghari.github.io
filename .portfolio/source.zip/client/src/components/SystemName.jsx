export default function SystemName({ name, expansion, as = "h2", className = "" }) {
  const Tag = as;

  return (
    <div className={`system-name ${className}`.trim()}>
      <Tag className="system-name-acronym">{name}</Tag>
      {expansion && <p className="system-name-expansion">{expansion}</p>}
    </div>
  );
}
