import { useEffect, useMemo, useState } from "react";
import { Link, useOutletContext } from "react-router-dom";
import { FaEnvelope, FaLocationDot, FaArrowDown } from "react-icons/fa6";
import { useReveal } from "../hooks/useReveal.js";
import { useCountUp } from "../hooks/useCountUp.js";

const TYPE = {
  command: { min: 62, max: 118 },
  response: { min: 22, max: 48 },
  think: { min: 520, max: 780 },
  gap: { min: 680, max: 980 },
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function typeDelay(kind, char, prevChar) {
  const { min, max } = TYPE[kind];
  let delay = min + Math.random() * (max - min);

  if (char === " ") delay += 35 + Math.random() * 45;
  if (prevChar === " " && char !== " ") delay += 25 + Math.random() * 35;
  if (char === "-" || char === "—") delay += 60 + Math.random() * 80;

  return delay;
}

function buildExchanges(profile) {
  const location = [profile.city, profile.country].filter(Boolean).join(", ");

  return [
    {
      command: { prompt: "$", text: "whoami" },
      response: {
        prompt: ">",
        text: `${profile.name?.toLowerCase().replace(/\s+/g, ".") || "danial.zolfaghari"} — security & backend engineer`,
      },
    },
    {
      command: { prompt: "$", text: "locate --city" },
      response: { prompt: ">", text: `${location || "Tehran, Iran"} · GMT+3:30` },
    },
    {
      command: { prompt: "$", text: "status" },
      response: {
        prompt: "✓",
        text: profile.availability || "Open to opportunities",
        success: true,
      },
    },
  ];
}

function StatCounter({ highlight, active }) {
  const num = typeof highlight.value === "number" ? highlight.value : parseInt(highlight.value, 10) || 0;
  const count = useCountUp(num, active);
  const suffix = highlight.suffix || (String(highlight.value).match(/\+/) ? "+" : "");

  return (
    <div className="stat">
      <strong>{count}{suffix}</strong>
      <span>{highlight.label}</span>
    </div>
  );
}

async function typeText(text, kind, onUpdate, cancelled) {
  let prev = "";
  for (let i = 0; i < text.length; i += 1) {
    if (cancelled()) return;
    const char = text[i];
    await sleep(typeDelay(kind, char, prev));
    if (cancelled()) return;
    onUpdate(text.slice(0, i + 1));
    prev = char;
  }
}

export default function Hero({ profile }) {
  const { openContact } = useOutletContext() || {};
  const location = [profile.city, profile.country].filter(Boolean).join(", ");
  const { ref, visible } = useReveal(0.1);
  const exchanges = useMemo(() => buildExchanges(profile), [profile]);
  const [completedLines, setCompletedLines] = useState([]);
  const [activeLine, setActiveLine] = useState(null);
  const [typingDone, setTypingDone] = useState(false);

  useEffect(() => {
    if (!visible) return undefined;

    let cancelled = false;
    const isCancelled = () => cancelled;

    setCompletedLines([]);
    setActiveLine(null);
    setTypingDone(false);

    (async () => {
      await sleep(420);

      for (const exchange of exchanges) {
        const { command, response } = exchange;

        setActiveLine({ prompt: command.prompt, text: "", success: false });
        await typeText(
          command.text,
          "command",
          (text) => setActiveLine({ prompt: command.prompt, text, success: false }),
          isCancelled,
        );
        if (isCancelled()) return;

        setCompletedLines((prev) => [...prev, { prompt: command.prompt, text: command.text }]);
        setActiveLine(null);
        await sleep(TYPE.think.min + Math.random() * (TYPE.think.max - TYPE.think.min));
        if (isCancelled()) return;

        setActiveLine({
          prompt: response.prompt,
          text: "",
          success: Boolean(response.success),
        });
        await typeText(
          response.text,
          "response",
          (text) => setActiveLine({
            prompt: response.prompt,
            text,
            success: Boolean(response.success),
          }),
          isCancelled,
        );
        if (isCancelled()) return;

        setCompletedLines((prev) => [...prev, {
          prompt: response.prompt,
          text: response.text,
          success: Boolean(response.success),
        }]);
        setActiveLine(null);
        await sleep(TYPE.gap.min + Math.random() * (TYPE.gap.max - TYPE.gap.min));
      }

      if (!isCancelled()) setTypingDone(true);
    })();

    return () => {
      cancelled = true;
    };
  }, [visible, exchanges]);

  return (
    <section className="hero" id="home">
      <div className="hero-bg">
        <div className="hero-grid" />
        <div className="hero-glow hero-glow--1" />
        <div className="hero-glow hero-glow--2" />
        <div className="hero-noise" />
      </div>

      <div className="container hero-layout">
        <div ref={ref} className={`hero-content${visible ? " reveal--visible" : " reveal"}`}>
          <div className="hero-badge">
            <span className="pulse" />
            {profile.availability || "Available for opportunities"}
          </div>

          <h1 className="hero-title">
            <span className="hero-greeting">Engineering trust at scale.</span>
            I'm <span className="gradient-text">{profile.name?.split(" ")[0]}</span>
            <br />
            {profile.name?.split(" ").slice(1).join(" ")}
          </h1>

          <p className="hero-role">{profile.title}</p>
          <p className="hero-tagline">{profile.tagline}</p>

          {profile.philosophy && (
            <blockquote className="hero-quote">"{profile.philosophy}"</blockquote>
          )}

          <div className="hero-meta">
            {location && <span><FaLocationDot /> {location}</span>}
            {profile.email && (
              <a href={`mailto:${profile.email}`}><FaEnvelope /> {profile.email}</a>
            )}
          </div>

          <div className="hero-actions">
            <Link to="/work" className="btn btn-primary">
              <span>Explore my work</span>
            </Link>
            <button type="button" className="btn btn-ghost" onClick={() => openContact?.()}>
              <span>Start a conversation</span>
            </button>
          </div>

          {profile.highlights?.length > 0 && (
            <div className="hero-stats">
              {profile.highlights.map((h) => (
                <StatCounter key={h.label} highlight={h} active={visible} />
              ))}
            </div>
          )}
        </div>

        <div className={`hero-terminal${visible ? " reveal--visible" : " reveal"}`} style={{ "--delay": "0.15s" }}>
          <div className="terminal-bar">
            <span /><span /><span />
            <p>danial@portfolio ~ security-engine</p>
          </div>
          <div className="terminal-body">
            {completedLines.map((line, i) => (
              <div key={`done-${i}`} className={`terminal-line${line.success ? " terminal-line--ok" : ""}`}>
                <span className="terminal-prompt">{line.prompt}</span>
                <span>{line.text}</span>
              </div>
            ))}
            {activeLine && (
              <div className={`terminal-line${activeLine.success ? " terminal-line--ok" : ""}`}>
                <span className="terminal-prompt">{activeLine.prompt}</span>
                <span>
                  {activeLine.text}
                  <span className="terminal-cursor terminal-cursor--inline" aria-hidden="true" />
                </span>
              </div>
            )}
            {!activeLine && completedLines.length === 0 && (
              <span className="terminal-cursor" aria-hidden="true" />
            )}
            {typingDone && !activeLine && (
              <div className="terminal-line">
                <span className="terminal-prompt">$</span>
                <span>
                  <span className="terminal-cursor terminal-cursor--inline" aria-hidden="true" />
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      <a href="#about" className="hero-scroll" aria-label="Scroll down">
        <span>Scroll</span>
        <FaArrowDown />
      </a>
    </section>
  );
}
