import { useEffect, useMemo, useState } from "react";
import { Link, useOutletContext } from "react-router-dom";
import { FaArrowRight, FaEnvelope } from "react-icons/fa6";
import { useReveal } from "../hooks/useReveal.js";
import { useCountUp } from "../hooks/useCountUp.js";

const TYPE = {
  command: { min: 56, max: 108 },
  response: { min: 18, max: 38 },
  think: { min: 430, max: 720 },
  gap: { min: 520, max: 820 },
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function typeDelay(kind, char, prevChar) {
  const { min, max } = TYPE[kind];
  let delay = min + Math.random() * (max - min);

  if (char === " ") delay += 28 + Math.random() * 38;
  if (prevChar === " " && char !== " ") delay += 20 + Math.random() * 30;
  if (char === "-" || char === "—" || char === "·") delay += 45 + Math.random() * 65;

  return delay;
}

async function typeText(text, kind, onUpdate, cancelled) {
  let prev = "";
  for (let i = 0; i < text.length; i += 1) {
    if (cancelled()) return;
    const char = text[i];
    await sleep(typeDelay(kind, char, prev));
    if (cancelled()) return;
    onUpdate(text.slice(0, i + 1));
    prev = char;
  }
}

function buildExchanges(profile) {
  const handle = profile.name?.toLowerCase().replace(/\s+/g, ".") || "danial.zolfaghari";

  return [
    {
      command: { prompt: "$", text: "whoami" },
      response: {
        prompt: ">",
        text: `${handle} — IRT/EOC · network security · backend`,
      },
    },
    {
      command: { prompt: "$", text: "focus --current" },
      response: {
        prompt: ">",
        text: "traffic-analysis · DDoS · observability · applied-AI",
      },
    },
    {
      command: { prompt: "$", text: "data --stores" },
      response: {
        prompt: ">",
        text: "elasticsearch · postgresql · mysql · mongodb",
      },
    },
    {
      command: { prompt: "$", text: "status" },
      response: {
        prompt: "✓",
        text: profile.availability || "production engineering · active",
        success: true,
      },
    },
  ];
}

function StatCounter({ highlight, active }) {
  const num = typeof highlight.value === "number"
    ? highlight.value
    : parseInt(highlight.value, 10) || 0;
  const count = useCountUp(num, active);
  const suffix = highlight.suffix || (String(highlight.value).includes("+") ? "+" : "");

  return (
    <div className="hero-metric">
      <strong>{count}{suffix}</strong>
      <span>{highlight.label}</span>
    </div>
  );
}

export default function Hero({ profile }) {
  const { openContact } = useOutletContext() || {};
  const { ref, visible } = useReveal(0.08);
  const exchanges = useMemo(() => buildExchanges(profile), [profile]);
  const [completedLines, setCompletedLines] = useState([]);
  const [activeLine, setActiveLine] = useState(null);
  const [typingDone, setTypingDone] = useState(false);

  useEffect(() => {
    if (!visible) return undefined;

    let cancelled = false;
    const isCancelled = () => cancelled;

    setCompletedLines([]);
    setActiveLine(null);
    setTypingDone(false);

    (async () => {
      await sleep(380);

      for (const exchange of exchanges) {
        const { command, response } = exchange;

        setActiveLine({ prompt: command.prompt, text: "", success: false });
        await typeText(
          command.text,
          "command",
          (text) => setActiveLine({ prompt: command.prompt, text, success: false }),
          isCancelled,
        );
        if (isCancelled()) return;

        setCompletedLines((prev) => [...prev, { prompt: command.prompt, text: command.text }]);
        setActiveLine(null);
        await sleep(TYPE.think.min + Math.random() * (TYPE.think.max - TYPE.think.min));
        if (isCancelled()) return;

        setActiveLine({ prompt: response.prompt, text: "", success: Boolean(response.success) });
        await typeText(
          response.text,
          "response",
          (text) => setActiveLine({
            prompt: response.prompt,
            text,
            success: Boolean(response.success),
          }),
          isCancelled,
        );
        if (isCancelled()) return;

        setCompletedLines((prev) => [...prev, {
          prompt: response.prompt,
          text: response.text,
          success: Boolean(response.success),
        }]);
        setActiveLine(null);
        await sleep(TYPE.gap.min + Math.random() * (TYPE.gap.max - TYPE.gap.min));
      }

      if (!isCancelled()) setTypingDone(true);
    })();

    return () => {
      cancelled = true;
    };
  }, [visible, exchanges]);

  return (
    <section className="hero" id="home">
      <div className="hero-bg" aria-hidden="true">
        <div className="hero-grid" />
        <div className="hero-spotlight" />
      </div>

      <div ref={ref} className={`container hero-shell${visible ? " reveal--visible" : " reveal"}`}>
        <div className="hero-kicker-row">
          <span className="hero-kicker">Portfolio / 2026</span>
          <span className="hero-availability"><i /> {profile.availability || "Open to engineering conversations"}</span>
        </div>

        <div className="hero-layout">
          <div className="hero-content">
            <p className="hero-eyebrow">IRT / EOC · Network Security · Backend · AI/Data</p>
            <h1 className="hero-title">
              I engineer systems that stay useful
              <span> when production gets difficult.</span>
            </h1>
            <p className="hero-intro">
              I&apos;m <strong>{profile.name}</strong>. I work across incident response, network traffic analysis,
              DDoS operations, backend systems, observability, automation, and evidence-driven AI over operational data.
            </p>

            <div className="hero-actions">
              <Link to="/work" className="btn btn-primary">
                View selected work <FaArrowRight />
              </Link>
              <button type="button" className="btn btn-ghost" onClick={() => openContact?.()}>
                Start a conversation
              </button>
            </div>

            <div className="hero-contactline">
              {profile.email && <a href={`mailto:${profile.email}`}><FaEnvelope /> {profile.email}</a>}
            </div>
          </div>

          <aside className="hero-terminal hero-terminal--redesign" aria-label="Interactive engineering terminal">
            <div className="terminal-bar">
              <span /><span /><span />
              <p>danial@portfolio ~ security-engine</p>
            </div>
            <div className="terminal-body">
              {completedLines.map((line, i) => (
                <div key={`done-${i}`} className={`terminal-line${line.success ? " terminal-line--ok" : ""}`}>
                  <span className="terminal-prompt">{line.prompt}</span>
                  <span>{line.text}</span>
                </div>
              ))}

              {activeLine && (
                <div className={`terminal-line${activeLine.success ? " terminal-line--ok" : ""}`}>
                  <span className="terminal-prompt">{activeLine.prompt}</span>
                  <span>
                    {activeLine.text}
                    <span className="terminal-cursor terminal-cursor--inline" aria-hidden="true" />
                  </span>
                </div>
              )}

              {!activeLine && completedLines.length === 0 && (
                <span className="terminal-cursor" aria-hidden="true" />
              )}

              {typingDone && !activeLine && (
                <div className="terminal-line terminal-line--ready">
                  <span className="terminal-prompt">$</span>
                  <span>
                    <span className="terminal-cursor terminal-cursor--inline" aria-hidden="true" />
                  </span>
                </div>
              )}
            </div>
            <div className="terminal-footer" aria-hidden="true">
              <span>interactive session</span>
              <span>UTF-8</span>
            </div>
          </aside>
        </div>

        {profile.highlights?.length > 0 && (
          <div className="hero-metrics">
            {profile.highlights.map((highlight) => (
              <StatCounter key={highlight.label} highlight={highlight} active={visible} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
