import { Link, useOutletContext } from "react-router-dom";
import {
  FaArrowRight,
  FaBriefcase,
  FaCheck,
  FaEnvelope,
  FaShieldHalved,
  FaCode,
  FaDatabase,
  FaWaveSquare,
} from "react-icons/fa6";
import { useReveal } from "../hooks/useReveal.js";
import { useCountUp } from "../hooks/useCountUp.js";

function StatCounter({ highlight, active }) {
  const num = typeof highlight.value === "number"
    ? highlight.value
    : parseInt(highlight.value, 10) || 0;
  const count = useCountUp(num, active);
  const suffix = highlight.suffix || (String(highlight.value).includes("+") ? "+" : "");

  return (
    <div className="hero-metric">
      <strong>{count}{suffix}</strong>
      <span>{highlight.label}</span>
    </div>
  );
}

const DISCIPLINES = [
  { label: "Security operations", Icon: FaShieldHalved },
  { label: "Network analysis", Icon: FaWaveSquare },
  { label: "Backend engineering", Icon: FaCode },
  { label: "AI & data systems", Icon: FaDatabase },
];

export default function Hero({ profile }) {
  const { openContact } = useOutletContext() || {};
  const { ref, visible } = useReveal(0.08);

  return (
    <section className="hero" id="home">
      <div className="hero-bg" aria-hidden="true">
        <div className="hero-grid" />
        <div className="hero-spotlight" />
      </div>

      <div ref={ref} className={`container hero-shell${visible ? " reveal--visible" : " reveal"}`}>
        <div className="hero-kicker-row">
          <span className="hero-kicker">Portfolio / 2026</span>
          <span className="hero-availability"><i /> {profile.availability || "Open to engineering conversations"}</span>
        </div>

        <div className="hero-layout">
          <div className="hero-content">
            <p className="hero-eyebrow">IRT / EOC · Network Security · Backend · AI/Data</p>
            <h1 className="hero-title">
              I engineer systems that stay useful
              <span> when production gets difficult.</span>
            </h1>
            <p className="hero-intro">
              I&apos;m <strong>{profile.name}</strong>. I work across incident response, network traffic analysis,
              DDoS operations, backend systems, observability, automation, and evidence-driven AI over operational data.
            </p>

            <div className="hero-actions">
              <Link to="/work" className="btn btn-primary">
                View selected work <FaArrowRight />
              </Link>
              <button type="button" className="btn btn-ghost" onClick={() => openContact?.()}>
                Start a conversation
              </button>
            </div>

            <div className="hero-contactline">
              {profile.email && <a href={`mailto:${profile.email}`}><FaEnvelope /> {profile.email}</a>}
            </div>
          </div>

          <aside className="hero-profile" aria-label="Engineering profile">
            <div className="hero-profile-head">
              <div>
                <span className="hero-profile-label">Engineering profile</span>
                <h2>{profile.name}</h2>
              </div>
              <span className="hero-profile-status"><FaCheck /> Active</span>
            </div>

            <div className="hero-role-card">
              <span>Current role</span>
              <strong>{profile.title}</strong>
              <p><FaBriefcase /> {profile.company || "Razhman"} · Production engineering</p>
            </div>

            <div className="hero-discipline-list">
              {DISCIPLINES.map(({ label, Icon }) => (
                <div key={label} className="hero-discipline">
                  <Icon />
                  <span>{label}</span>
                  <i />
                </div>
              ))}
            </div>

            <div className="hero-principle">
              <span>Operating principle</span>
              <p>{profile.philosophy}</p>
            </div>
          </aside>
        </div>

        {profile.highlights?.length > 0 && (
          <div className="hero-metrics">
            {profile.highlights.map((highlight) => (
              <StatCounter key={highlight.label} highlight={highlight} active={visible} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
