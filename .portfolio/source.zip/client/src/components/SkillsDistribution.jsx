import { useMemo } from "react";

const COLORS = ["#2dd4a8", "#34d399", "#10b981", "#059669", "#6ee7b7"];

const SHORT_LABELS = {
  "Programming & Backend": "Backend",
  "Network Security & Operations": "Security",
  "Data & Observability": "Data",
  "AI & Machine Learning": "AI / ML",
  "Systems & Automation": "Systems",
};

export default function SkillsDistribution({ skills, visible }) {
  const rows = useMemo(() => {
    const groups = skills || [];
    const max = Math.max(...groups.map((g) => g.items.length), 1);
    return groups.map((g, i) => ({
      label: SHORT_LABELS[g.category] || g.category,
      full: g.category,
      count: g.items.length,
      pct: Math.round((g.items.length / max) * 100),
      color: COLORS[i % COLORS.length],
    }));
  }, [skills]);

  const total = rows.reduce((n, r) => n + r.count, 0);

  return (
    <div className={`skills-distribution glass-card${visible ? " skills-distribution--visible" : ""}`}>
      <div className="skills-distribution-head">
        <h3>Stack breadth</h3>
        <span>{total} technologies · {rows.length} domains</span>
      </div>
      <ul className="skills-distribution-bars">
        {rows.map((row, i) => (
          <li key={row.full} style={{ "--i": i, "--bar-color": row.color }}>
            <div className="skills-distribution-meta">
              <span title={row.full}>{row.label}</span>
              <strong>{row.count}</strong>
            </div>
            <div className="skills-distribution-track">
              <div
                className="skills-distribution-fill"
                style={{ "--pct": `${row.pct}%`, "--bar-color": row.color }}
              />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
