import { FaBell, FaServer, FaChartLine } from "react-icons/fa6";

const TOPO_NODES = [
  { cx: 50, cy: 50, r: 6 },
  { cx: 22, cy: 30, r: 4 },
  { cx: 78, cy: 28, r: 4 },
  { cx: 20, cy: 68, r: 3.5 },
  { cx: 80, cy: 65, r: 4 },
  { cx: 50, cy: 18, r: 3.5 },
];

const TOPO_EDGES = [[0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [1, 3], [2, 4]];

const BARS = [40, 55, 35, 70, 45, 80, 50, 65, 90, 55, 75, 60];

function Topology({ className = "" }) {
  return (
    <div className={`pv-vida-topology${className ? ` ${className}` : ""}`}>
      <svg viewBox="0 0 100 80" preserveAspectRatio="xMidYMid meet">
        {TOPO_EDGES.map(([a, b], i) => (
          <line
            key={i}
            x1={TOPO_NODES[a].cx}
            y1={TOPO_NODES[a].cy}
            x2={TOPO_NODES[b].cx}
            y2={TOPO_NODES[b].cy}
            className="pv-topo-edge"
          />
        ))}
        {TOPO_NODES.map((n, i) => (
          <circle key={i} cx={n.cx} cy={n.cy} r={n.r} className={i === 0 ? "pv-topo-core" : "pv-topo-node"} />
        ))}
      </svg>
    </div>
  );
}

export default function VidaVisual({ compact = false, expanded = false }) {
  const isCompact = compact && !expanded;

  if (isCompact) {
    return (
      <div className="pv pv--vida pv--compact pv--preview" aria-hidden="true">
        <div className="pv-body pv-body--vida pv-body--preview pv-preview--dashboard">
          <div className="pv-preview-kpis-row">
            <div className="pv-preview-kpi-box pv-preview-kpi-box--crit">
              <FaBell />
              <strong>12</strong>
              <span>Critical</span>
            </div>
            <div className="pv-preview-kpi-box pv-preview-kpi-box--warn">
              <FaServer />
              <strong>47</strong>
              <span>Warnings</span>
            </div>
            <div className="pv-preview-kpi-box pv-preview-kpi-box--ok">
              <FaChartLine />
              <strong>98%</strong>
              <span>Healthy</span>
            </div>
          </div>
          <div className="pv-preview-chart">
            {BARS.map((h, i) => (
              <div key={i} className="pv-bar" style={{ "--h": `${h}%` }} />
            ))}
          </div>
          <div className="pv-preview-feed">
            <span className="pv-sev pv-sev--0" /> Elastic cluster alert
            <span className="pv-sev pv-sev--1" /> Server disk threshold
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`pv pv--vida${expanded ? " pv--expanded" : ""}`} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>VIDA · Visual Infrastructure Dashboard & Alerting</p>
        <span className="pv-live">v2.0.1</span>
      </div>
      <div className="pv-body pv-body--vida">
        <div className="pv-vida-kpis">
          <div className="pv-kpi pv-kpi--crit"><FaBell /><strong>12</strong><span>Critical</span></div>
          <div className="pv-kpi pv-kpi--warn"><FaServer /><strong>47</strong><span>Warnings</span></div>
          <div className="pv-kpi pv-kpi--ok"><FaChartLine /><strong>98%</strong><span>Healthy</span></div>
        </div>
        <div className="pv-vida-main">
          <Topology />
          <div className="pv-vida-chart-row">
            <div className="pv-vida-chart">
              {BARS.map((h, i) => (
                <div key={i} className="pv-bar" style={{ "--h": `${h}%`, animationDelay: `${i * 0.06}s` }} />
              ))}
            </div>
            <div className="pv-vida-ring">
              <svg viewBox="0 0 36 36">
                <path className="pv-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                <path className="pv-ring-fill" strokeDasharray="98, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
              </svg>
              <strong>98%</strong>
              <span>Uptime</span>
            </div>
          </div>
        </div>
        <div className="pv-vida-feed">
          {["Elastic cluster · shard alert", "Server disk · threshold", "Platform API · 200 OK"].map((t, i) => (
            <div key={i} className="pv-feed-row" style={{ animationDelay: `${i * 0.15}s` }}>
              <span className={`pv-sev pv-sev--${i}`} />
              {t}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
