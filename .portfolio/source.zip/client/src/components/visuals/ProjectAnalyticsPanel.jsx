import { getProjectSlug } from "../../utils/projectHelpers.js";

const ANALYTICS_MODULES = [
  { label: "Activity", value: 87, color: "#38bdf8" },
  { label: "Economy", value: 64, color: "#34d399" },
  { label: "Sessions", value: 92, color: "#818cf8" },
  { label: "Jobs", value: 71, color: "#fbbf24" },
];

function PanelShell({ title, subtitle, children }) {
  return (
    <div className="case-analytics glass-card">
      <header className="case-analytics-head">
        <div>
          <span className="card-label">Live system sketch</span>
          <h3>{title}</h3>
          {subtitle && <p>{subtitle}</p>}
        </div>
      </header>
      <div className="case-analytics-body">{children}</div>
    </div>
  );
}

function Donut({ value, label, color, size = 88 }) {
  return (
    <div className="pa-donut" style={{ "--donut-pct": value, "--donut-color": color, width: size, height: size }}>
      <svg viewBox="0 0 36 36">
        <path className="pa-donut-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        <path className="pa-donut-fill" strokeDasharray={`${value}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
      </svg>
      <div className="pa-donut-center">
        <strong>{value}%</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

function BarChart({ items, accent }) {
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <ul className="pa-bars">
      {items.map((item, i) => (
        <li
          key={item.label}
          style={{
            "--i": i,
            "--bar-accent": item.color || accent,
            "--fill-w": `${(item.value / max) * 100}%`,
          }}
        >
          <span>{item.label}</span>
          <div className="pa-bar-track">
            <div className="pa-bar-fill" />
          </div>
          <strong>{item.value}</strong>
        </li>
      ))}
    </ul>
  );
}

function Sparkline({ points, color, id }) {
  const w = 240;
  const h = 56;
  const pad = 4;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const step = (w - pad * 2) / (points.length - 1);
  const d = points
    .map((v, i) => {
      const x = pad + i * step;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="pa-sparkline">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${d} L${w - pad},${h - pad} L${pad},${h - pad} Z`} fill={`url(#${id})`} />
      <path d={d} fill="none" stroke={color} strokeWidth="2" />
    </svg>
  );
}

function VidaPanel() {
  return (
    <PanelShell title="Monitoring pulse" subtitle="Alert distribution and service health across monitor types.">
      <div className="pa-grid pa-grid--3">
        <Donut value={98} label="Healthy" color="#34d399" />
        <Donut value={12} label="Critical" color="#f87171" />
        <Donut value={47} label="Warnings" color="#fbbf24" />
      </div>
      <div className="pa-split">
        <div>
          <span className="pa-mini-label">24h alert volume</span>
          <Sparkline points={[12, 18, 14, 22, 19, 28, 24, 31, 26, 35, 29, 32]} color="#34d399" id="vida-spark" />
        </div>
        <BarChart
          accent="#34d399"
          items={[
            { label: "Elastic", value: 92 },
            { label: "Servers", value: 88 },
            { label: "APIs", value: 95 },
            { label: "Agents", value: 84 },
          ]}
        />
      </div>
    </PanelShell>
  );
}

function AndePanel() {
  return (
    <PanelShell title="Traffic triage sketch" subtitle="Layer-1 heuristics vs discovery proposals — read-only analysis windows.">
      <div className="pa-grid pa-grid--2">
        <div className="pa-stat-ring">
          <Donut value={94} label="Layer-1 conf." color="#d4ff3c" size={100} />
          <ul className="pa-legend">
            <li><i style={{ background: "#d4ff3c" }} /> DoS · single source</li>
            <li><i style={{ background: "#f472b6" }} /> DDoS · multi source</li>
          </ul>
        </div>
        <BarChart
          accent="#d4ff3c"
          items={[
            { label: "30s detection", value: 100, color: "#d4ff3c" },
            { label: "2m discovery", value: 68, color: "#f472b6" },
            { label: "15m traffic", value: 45, color: "#818cf8" },
            { label: "Admin GT", value: 22, color: "#34d399" },
          ]}
        />
      </div>
      <Sparkline points={[40, 42, 38, 55, 48, 90, 85, 72, 44, 41, 39, 42]} color="#f472b6" id="ande-spark" />
    </PanelShell>
  );
}

function WorldMapPanel() {
  return (
    <PanelShell title="Knowledge graph density" subtitle="Semantic node coverage and retrieval fusion weights.">
      <div className="pa-grid pa-grid--3">
        <Donut value={78} label="Schema mapped" color="#38bdf8" />
        <Donut value={65} label="RRF fusion" color="#34d399" />
        <Donut value={91} label="NL intent" color="#818cf8" />
      </div>
      <BarChart
        accent="#38bdf8"
        items={[
          { label: "Traffic", value: 88, color: "#38bdf8" },
          { label: "Domain", value: 72, color: "#34d399" },
          { label: "Attack", value: 65, color: "#f472b6" },
          { label: "Ranking", value: 54, color: "#fbbf24" },
        ]}
      />
    </PanelShell>
  );
}

function NexusPanel() {
  return (
    <PanelShell title="Platform dependency map" subtitle="How the proprietary core fans out to downstream systems.">
      <div className="pa-iso-mini">
        <div className="pa-iso-node pa-iso-node--core">Nexus Core</div>
        <div className="pa-iso-lines" />
        <div className="pa-iso-row">
          {["Economy", "Jobs", "Admin", "Analytics"].map((n) => (
            <div key={n} className="pa-iso-node pa-iso-node--child">{n}</div>
          ))}
        </div>
      </div>
      <BarChart
        accent="#fbbf24"
        items={[
          { label: "Core exports", value: 100, color: "#fbbf24" },
          { label: "Resources", value: 120, color: "#38bdf8" },
          { label: "MySQL tables", value: 48, color: "#34d399" },
          { label: "Admin cmds", value: 36, color: "#f472b6" },
        ]}
      />
    </PanelShell>
  );
}

function EconomyPanel() {
  return (
    <PanelShell title="Market simulation" subtitle="Dynamic pricing index driven by player activity — not static shop configs.">
      <Sparkline points={[42, 48, 45, 58, 52, 67, 61, 74, 69, 82, 78, 88]} color="#f472b6" id="eco-spark" />
      <div className="pa-grid pa-grid--3 pa-grid--compact">
        <div className="pa-kpi"><strong>1.08</strong><span>Inflation</span></div>
        <div className="pa-kpi"><strong>+12%</strong><span>Index 7d</span></div>
        <div className="pa-kpi"><strong>Live</strong><span>Ledger</span></div>
      </div>
      <BarChart
        accent="#f472b6"
        items={[
          { label: "Commodities", value: 82, color: "#f472b6" },
          { label: "Services", value: 64, color: "#fbbf24" },
          { label: "Tax yield", value: 38, color: "#34d399" },
          { label: "Exchange", value: 71, color: "#38bdf8" },
        ]}
      />
    </PanelShell>
  );
}

function AnalyticsPanel() {
  return (
    <PanelShell title="Operator KPI board" subtitle="External Flask modules — read-only intelligence outside the game process.">
      <div className="pa-grid pa-grid--4">
        {ANALYTICS_MODULES.map((m) => (
          <Donut key={m.label} value={m.value} label={m.label} color={m.color} size={72} />
        ))}
      </div>
      <BarChart
        accent="#38bdf8"
        items={[
          { label: "Sessions", value: 92, color: "#38bdf8" },
          { label: "Activity score", value: 87, color: "#34d399" },
          { label: "Economy KPI", value: 64, color: "#fbbf24" },
          { label: "Job metrics", value: 71, color: "#818cf8" },
        ]}
      />
    </PanelShell>
  );
}

const PANELS = {
  vida: VidaPanel,
  ande: AndePanel,
  "ai-data-analyzer": WorldMapPanel,
  "nexus-core": NexusPanel,
  "living-economy": EconomyPanel,
  "server-analytics": AnalyticsPanel,
};

export default function ProjectAnalyticsPanel({ project }) {
  const slug = getProjectSlug(project);
  const Panel = PANELS[slug];
  if (!Panel) return null;
  return <Panel />;
}
