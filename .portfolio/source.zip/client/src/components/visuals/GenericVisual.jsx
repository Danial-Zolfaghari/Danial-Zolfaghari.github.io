import { FaCode } from "react-icons/fa6";

export default function GenericVisual({ compact, name }) {
  return (
    <div className={`pv pv--generic${compact ? " pv--compact" : ""}`} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>{name || "Project"}</p>
      </div>
      <div className="pv-body pv-body--generic">
        <FaCode className="pv-generic-icon" />
        <div className="pv-generic-lines">
          <span /><span /><span style={{ width: "60%" }} />
        </div>
      </div>
    </div>
  );
}
