/** External Flask Command Center — ops dashboard mockup */
const KPIS = [
  { value: "1.2k", label: "Sessions" },
  { value: "87", label: "Activity" },
  { value: "15+", label: "Modules" },
];

const MODULES = [
  { name: "Player KPIs", pct: 92 },
  { name: "Economy", pct: 68 },
  { name: "Job metrics", pct: 74 },
  { name: "Season stats", pct: 81 },
];

const HEAT = [
  0.15, 0.22, 0.35, 0.28, 0.45, 0.62, 0.55,
  0.18, 0.42, 0.58, 0.71, 0.48, 0.36, 0.52,
  0.25, 0.38, 0.82, 0.76, 0.64, 0.41, 0.33,
  0.2, 0.55, 0.68, 0.59, 0.88, 0.72, 0.46,
  0.12, 0.3, 0.44, 0.51, 0.67, 0.58, 0.39,
];

function Sparkline({ points, color }) {
  const w = 64;
  const h = 20;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const d = points
    .map((v, i) => {
      const x = (i / (points.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - 2) - 1;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="cmd-spark" aria-hidden="true">
      <path d={d} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export default function ServerAnalyticsVisual({ compact = false, expanded = false }) {
  const isCompact = compact && !expanded;

  const heatmap = (
    <div className="cmd-heatmap-wrap cmd-heatmap-wrap--hero">
      <div className="cmd-heatmap">
        {HEAT.map((o, i) => (
          <div
            key={i}
            className="cmd-cell"
            style={{ "--cell-o": o, animationDelay: `${i * 0.02}s` }}
          />
        ))}
      </div>
    </div>
  );

  if (isCompact) {
    return (
      <div className="pv pv--cmdcenter pv--compact pv--preview" aria-hidden="true">
        <div className="pv-body pv-body--cmdcenter pv-body--preview">
          {heatmap}
          <div className="pv-preview-strip">
            <span>1.2k Sessions</span>
            <span>87 Activity</span>
            <span>15+ Modules</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`pv pv--cmdcenter${expanded ? " pv--expanded" : ""}`} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>Command Center · Flask · :8010</p>
        <span className="pv-live">RO</span>
      </div>
      <div className="pv-body pv-body--cmdcenter">
        <div className="cmd-kpi-row">
          {KPIS.map((k) => (
            <div key={k.label} className="cmd-kpi">
              <strong>{k.value}</strong>
              <span>{k.label}</span>
            </div>
          ))}
        </div>

        <div className="cmd-layout">
          {heatmap}
          <div className="cmd-modules">
            <span className="cmd-panel-label">Operational modules</span>
            {MODULES.map((m, i) => (
              <div key={m.name} className="cmd-module" style={{ "--i": i }}>
                <div className="cmd-module-head">
                  <span>{m.name}</span>
                  <strong>{m.pct}%</strong>
                </div>
                <div className="cmd-module-bar">
                  <div className="cmd-module-fill" style={{ width: `${m.pct}%` }} />
                </div>
                <Sparkline points={[40, 48, 44, 52, m.pct - 10, m.pct - 4, m.pct]} color="#2dd4a8" />
              </div>
            ))}
          </div>
        </div>

        <div className="cmd-footer">
          <span>Read-only MySQL</span>
          <span>SQLite auth layer</span>
          <span>Outside FXServer</span>
        </div>
      </div>
    </div>
  );
}
