import { FaShieldHalved, FaWaveSquare } from "react-icons/fa6";

export default function AndeVisual({ compact = false, expanded = false, accent = "#d4ff3c" }) {
  const isCompact = compact && !expanded;

  const waveSvg = (
    <svg viewBox="0 0 200 100" className={`pv-wave-svg${isCompact ? " pv-wave-svg--preview" : ""}`} preserveAspectRatio="none">
      {[20, 40, 60, 80].map((y) => (
        <line key={y} x1="0" y1={y} x2="200" y2={y} className="pv-wave-grid" />
      ))}
      <path
        className="pv-wave pv-wave--base"
        d="M0,62 Q30,58 60,60 T120,58 T180,61 T200,58 L200,100 L0,100 Z"
      />
      <path
        className="pv-wave pv-wave--alert"
        d="M0,62 Q30,58 60,60 T120,58 T155,22 T200,28 L200,100 L0,100 Z"
      />
      <path
        className="pv-wave-line pv-wave-line--base"
        d="M0,62 Q30,58 60,60 T120,58 T180,61 T200,58"
        fill="none"
      />
      <path
        className="pv-wave-line pv-wave-line--alert"
        d="M0,62 Q30,58 60,60 T120,58 T155,22 T200,28"
        fill="none"
      />
      <line x1="155" y1="8" x2="155" y2="92" className="pv-wave-marker" />
      {isCompact && (
        <text x="162" y="18" className="pv-wave-tag">SPIKE</text>
      )}
    </svg>
  );

  if (isCompact) {
    return (
      <div className="pv pv--ande pv--compact pv--preview" style={{ "--ande-accent": accent }} aria-hidden="true">
        <div className="pv-body pv-body--ande pv-body--preview pv-preview--ande">
          <div className="pv-ande-preview-head">
            <FaShieldHalved />
            <span>Layer-1 · DoS/DDoS Triage</span>
            <strong>0.94</strong>
          </div>
          {waveSvg}
          <div className="pv-preview-strip">
            <span><FaWaveSquare /> LiveEngine · 30s</span>
            <span className="pv-preview-kpi--warn">Anomaly detected</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`pv pv--ande${expanded ? " pv--expanded" : ""}`} style={{ "--ande-accent": accent }} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>ANDE · Adaptive Network Defence Engine</p>
        <span className="pv-live">LIVE</span>
      </div>
      <div className="pv-body pv-body--ande">
        <div className="pv-ande-header">
          <FaShieldHalved />
          <div>
            <strong>Layer-1 · DoS/DDoS Triage</strong>
            <span>LiveEngine · 30s window · Read-only ES</span>
          </div>
          <div className="pv-score">0.94</div>
        </div>
        {waveSvg}
        <div className="pv-ande-labels">
          <span><FaWaveSquare /> Normal baseline</span>
          <span className="pv-ande-alert">Anomaly detected</span>
        </div>
        {expanded && (
          <div className="pv-ande-pps">
            {[32, 38, 35, 42, 88, 92, 78, 45, 40, 36].map((h, i) => (
              <div key={i} className="pv-bar pv-bar--ande" style={{ "--h": `${h}%`, animationDelay: `${i * 0.05}s` }} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
