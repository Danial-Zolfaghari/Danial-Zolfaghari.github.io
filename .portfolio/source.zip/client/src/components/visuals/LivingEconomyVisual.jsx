/** Market curve + commodity bars — Living Economy */
const PRICES = [42, 48, 45, 58, 52, 67, 61, 74, 69, 82, 78, 88];
const BARS = [35, 52, 44, 68, 55, 72, 48, 80, 62, 75];

function buildPath(values, w, h, pad) {
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const step = (w - pad * 2) / (values.length - 1);
  return values
    .map((v, i) => {
      const x = pad + i * step;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

export default function LivingEconomyVisual({ compact = false }) {
  const line = buildPath(PRICES, 200, 70, 8);
  const area = `${line} L192,62 L8,62 Z`;

  const chart = (
    <svg viewBox="0 0 200 70" className="pv-economy-chart" preserveAspectRatio="none">
          <defs>
            <linearGradient id="economy-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f472b6" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#f472b6" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} fill="url(#economy-fill)" className="pv-economy-area" />
          <path d={line} fill="none" stroke="#f472b6" strokeWidth="2" className="pv-economy-line" />
          {PRICES.map((v, i) => {
            const x = 8 + (i * 184) / (PRICES.length - 1);
            const y = 62 - ((v - 42) / 46) * 48;
            return i === PRICES.length - 1 ? (
              <circle key={i} cx={x} cy={y} r="3" className="pv-economy-dot" />
            ) : null;
          })}
    </svg>
  );

  if (compact) {
    return (
      <div className="pv pv--economy pv--compact pv--preview" aria-hidden="true">
        <div className="pv-body pv-body--economy pv-body--preview">
          {chart}
          <div className="pv-preview-strip">
            <span>Commodity Index</span>
            <span className="pv-preview-kpi--ok">+12.4%</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pv pv--economy pv--expanded" aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>Living Economy · Market Index</p>
        <span className="pv-live">LIVE</span>
      </div>
      <div className="pv-body pv-body--economy">
        <div className="pv-economy-head">
          <div>
            <strong>Commodity Index</strong>
            <span>Player-driven pricing</span>
          </div>
          <div className="pv-economy-delta">+12.4%</div>
        </div>
        {chart}
        <div className="pv-economy-bars">
          {BARS.slice(0, 10).map((h, i) => (
            <div key={i} className="pv-bar pv-bar--economy" style={{ "--h": `${h}%`, animationDelay: `${i * 0.05}s` }} />
          ))}
        </div>
        <div className="pv-economy-ticker">
          <span>Inflation index · 1.08</span>
          <span>Wealth tax · active</span>
          <span>Ledger · synced</span>
        </div>
      </div>
    </div>
  );
}
