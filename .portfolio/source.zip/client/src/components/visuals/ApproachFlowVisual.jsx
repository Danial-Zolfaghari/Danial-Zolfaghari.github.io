export default function ApproachFlowVisual({ steps = [], active = false }) {
  const nodes = steps.slice(0, 3).map((s, i) => ({
    id: i,
    step: s.step,
    title: s.title?.split(" ").slice(0, 2).join(" ") || s.title,
  }));

  while (nodes.length < 3) {
    nodes.push({ id: nodes.length, step: `0${nodes.length + 1}`, title: "Step" });
  }

  const positions = [
    { x: 140, y: 36 },
    { x: 140, y: 132 },
    { x: 140, y: 228 },
  ];

  return (
    <div className={`approach-flow${active ? " approach-flow--active" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 280 280" className="approach-flow-svg">
        <defs>
          <linearGradient id="approach-flow-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#2dd4a8" stopOpacity="0.85" />
            <stop offset="100%" stopColor="#10b981" stopOpacity="0.55" />
          </linearGradient>
          <marker id="approach-arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#34d399" opacity="0.8" />
          </marker>
        </defs>

        <path
          className="approach-flow-path approach-flow-path--main"
          d="M 140 56 L 140 108"
          fill="none"
          stroke="url(#approach-flow-grad)"
          strokeWidth="2"
          markerEnd="url(#approach-arrow)"
        />
        <path
          className="approach-flow-path approach-flow-path--main"
          d="M 140 152 L 140 204"
          fill="none"
          stroke="url(#approach-flow-grad)"
          strokeWidth="2"
          markerEnd="url(#approach-arrow)"
        />
        <path
          className="approach-flow-path approach-flow-path--loop"
          d="M 108 228 C 36 228, 36 36, 108 36"
          fill="none"
          stroke="rgba(45, 212, 168, 0.4)"
          strokeWidth="1.5"
          strokeDasharray="5 4"
          opacity="0.55"
          markerEnd="url(#approach-arrow)"
        />

        {nodes.map((node, i) => {
          const { x, y } = positions[i];
          return (
            <g key={node.id} className="approach-flow-node" style={{ "--node-i": i }}>
              <circle cx={x} cy={y} r="22" className="approach-flow-node-ring" />
              <circle cx={x} cy={y} r="16" className="approach-flow-node-core" />
              <text x={x} y={y - 1} textAnchor="middle" className="approach-flow-node-step">
                {node.step}
              </text>
              <text x={x} y={y + 38} textAnchor="middle" className="approach-flow-node-label">
                {node.title}
              </text>
            </g>
          );
        })}

        <text x="22" y="142" className="approach-flow-loop-label" transform="rotate(-90 22 142)">
          feedback
        </text>
      </svg>
    </div>
  );
}
