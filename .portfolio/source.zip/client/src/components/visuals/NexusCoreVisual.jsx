/** Isometric 3D platform stack — Nexus Core */
export default function NexusCoreVisual({ compact = false }) {
  const isoScene = (
    <div className="iso-scene">
          <div className="iso-orbit iso-orbit--1" />
          <div className="iso-orbit iso-orbit--2" />
          <div className="iso-stack">
            <div className="iso-layer iso-layer--top">
              <span>120+</span>
              <small>Resources</small>
            </div>
            <div className="iso-layer iso-layer--mid">
              <span>Jobs · Economy</span>
              <small>Game layer</small>
            </div>
            <div className="iso-layer iso-layer--base">
              <span>Nexus</span>
              <small>Core API</small>
            </div>
            <div className="iso-layer iso-layer--floor">
              <span>MySQL</span>
            </div>
          </div>
        </div>
  );

  if (compact) {
    return (
      <div className="pv pv--nexus pv--compact pv--preview" aria-hidden="true">
        <div className="pv-body pv-body--iso pv-body--preview">
          {isoScene}
          <div className="pv-preview-strip">
            <span>120+ Resources</span>
            <span>Core API</span>
            <span>MySQL</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pv pv--nexus pv--expanded" aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>Nexus Core · Platform Stack</p>
        <span className="pv-live">CORE</span>
      </div>
      <div className="pv-body pv-body--iso">
        {isoScene}
        <div className="iso-legend">
          <span><i className="pv-dot pv-dot--warn" /> Shared object</span>
          <span><i className="pv-dot pv-dot--ok" /> Player lifecycle</span>
          <span><i className="pv-dot pv-dot--info" /> oxmysql</span>
        </div>
      </div>
    </div>
  );
}
