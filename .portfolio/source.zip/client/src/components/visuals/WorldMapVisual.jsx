import { useId } from "react";

/** Semantic brain-graph — AI Data Analyzer (distinct from VIDA dashboard) */
export default function WorldMapVisual({ compact = false, expanded = false, accent = "#38bdf8" }) {
  const isCompact = compact && !expanded;
  const glowId = useId();

  const nodes = [
    { cx: 50, cy: 50, r: 10, delay: 0, label: "CORE" },
    { cx: 24, cy: 26, r: 5.5, delay: 0.2 },
    { cx: 76, cy: 24, r: 5.5, delay: 0.4 },
    { cx: 16, cy: 58, r: 4.5, delay: 0.6 },
    { cx: 84, cy: 56, r: 5.5, delay: 0.3 },
    { cx: 32, cy: 80, r: 4.5, delay: 0.5 },
    { cx: 68, cy: 78, r: 4.5, delay: 0.7 },
    { cx: 50, cy: 14, r: 4.5, delay: 0.1 },
    { cx: 12, cy: 38, r: 3.5, delay: 0.45 },
    { cx: 88, cy: 36, r: 3.5, delay: 0.55 },
  ];

  const edges = [
    [0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6], [0, 7], [0, 8], [0, 9],
    [1, 3], [2, 4], [5, 6], [1, 7], [2, 7], [8, 1], [9, 2],
  ];

  const mapSvg = (
    <svg viewBox="0 0 100 100" className="pv-map-svg">
      <defs>
        <radialGradient id={glowId} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={accent} stopOpacity="0.35" />
          <stop offset="100%" stopColor={accent} stopOpacity="0" />
        </radialGradient>
        <pattern id={`${glowId}-hex`} width="8" height="8" patternUnits="userSpaceOnUse">
          <path d="M4 0 L8 2.3 L8 5.7 L4 8 L0 5.7 L0 2.3 Z" fill="none" stroke={accent} strokeOpacity="0.12" strokeWidth="0.3" />
        </pattern>
      </defs>
      <rect width="100" height="100" fill={`url(#${glowId}-hex)`} opacity="0.6" />
      <circle cx="50" cy="50" r="44" fill="none" stroke={accent} strokeOpacity="0.15" strokeWidth="0.5" strokeDasharray="3 4" className="pv-map-orbit" />
      <circle cx="50" cy="50" r="32" fill="none" stroke={accent} strokeOpacity="0.1" strokeWidth="0.4" strokeDasharray="2 5" />
      <circle cx="50" cy="50" r="38" fill={`url(#${glowId})`} />
      {edges.map(([a, b], i) => (
        <line
          key={i}
          x1={nodes[a].cx}
          y1={nodes[a].cy}
          x2={nodes[b].cx}
          y2={nodes[b].cy}
          className="pv-map-edge"
          style={{ "--map-accent": accent, animationDelay: `${i * 0.06}s` }}
        />
      ))}
      {nodes.map((n, i) => (
        <g key={i} className="pv-map-node" style={{ animationDelay: `${n.delay}s` }}>
          {i > 0 && <circle cx={n.cx} cy={n.cy} r={n.r + 5} className="pv-map-pulse" style={{ stroke: accent }} />}
          <circle
            cx={n.cx}
            cy={n.cy}
            r={n.r}
            className={i === 0 ? "pv-map-core" : "pv-map-dot"}
            style={{ fill: i === 0 ? accent : undefined, "--map-accent": accent }}
          />
          {i === 0 && (
            <text x={n.cx} y={n.cy + 1} textAnchor="middle" className="pv-map-core-label">AI</text>
          )}
        </g>
      ))}
    </svg>
  );

  if (isCompact) {
    return (
      <div className="pv pv--worldmap pv--compact pv--preview" style={{ "--map-accent": accent }} aria-hidden="true">
        <div className="pv-body pv-body--map pv-body--preview pv-preview--brainmap">
          {mapSvg}
          <div className="pv-preview-strip pv-preview-strip--map">
            <span>Semantic World Map</span>
            <span>BrainGraph</span>
            <span>RRF fusion</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`pv pv--worldmap${expanded ? " pv--expanded" : ""}`} style={{ "--map-accent": accent }} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>World Map · BrainGraph</p>
        <span className="pv-live">LIVE</span>
      </div>
      <div className="pv-body pv-body--map">
        {mapSvg}
        <div className="pv-map-hud">
          <span><i className="pv-dot pv-dot--ok" /> CONFIRMED</span>
          <span><i className="pv-dot pv-dot--warn" /> 8 node types</span>
          <span><i className="pv-dot pv-dot--info" /> RRF fusion</span>
        </div>
        <div className="pv-map-scan" />
      </div>
    </div>
  );
}
