import { getProjectSlug } from "../../utils/projectHelpers.js";
import WorldMapVisual from "./WorldMapVisual.jsx";
import VidaVisual from "./VidaVisual.jsx";
import AndeVisual from "./AndeVisual.jsx";
import NexusCoreVisual from "./NexusCoreVisual.jsx";
import LivingEconomyVisual from "./LivingEconomyVisual.jsx";
import ServerAnalyticsVisual from "./ServerAnalyticsVisual.jsx";
import GenericVisual from "./GenericVisual.jsx";

const MAP = {
  "ai-data-analyzer": WorldMapVisual,
  vida: VidaVisual,
  ande: AndeVisual,
  "nexus-core": NexusCoreVisual,
  "living-economy": LivingEconomyVisual,
  "server-analytics": ServerAnalyticsVisual,
};

export default function ProjectVisual({ project, compact = false, expanded = false }) {
  const slug = getProjectSlug(project);
  const Visual = MAP[slug] || GenericVisual;
  const isCompact = compact && !expanded;
  const accent = project?.accent || "#34d399";

  return (
    <div
      className={`pv-wrap${expanded ? " pv-wrap--expanded" : ""}${isCompact ? " pv-wrap--card" : ""}`}
      style={{ "--pv-accent": accent }}
    >
      <Visual compact={isCompact} expanded={expanded} accent={accent} name={project?.name} slug={slug} />
    </div>
  );
}
