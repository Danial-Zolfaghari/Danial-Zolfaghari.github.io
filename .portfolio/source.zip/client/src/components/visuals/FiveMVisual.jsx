import { FaChartLine, FaShieldHalved, FaCoins } from "react-icons/fa6";

const VARIANTS = {
  "nexus-core": {
    icon: FaShieldHalved,
    chrome: "Nexus Core · Platform",
    title: "Proprietary framework",
    sub: "Shared object · Player lifecycle",
  },
  "living-economy": {
    icon: FaCoins,
    chrome: "Living Economy · Exchange",
    title: "Real-money ecosystem",
    sub: "Inflation · Ledger · Dynamic pricing",
  },
  "server-analytics": {
    icon: FaChartLine,
    chrome: "Server Analytics · Flask",
    title: "External Command Center",
    sub: "Read-only MySQL · 15+ modules",
  },
};

export default function FiveMVisual({ compact = false, slug, name }) {
  const v = VARIANTS[slug] || {
    icon: FaChartLine,
    chrome: name || "FiveM Project",
    title: "Nexus script",
    sub: "Lua · Production",
  };
  const Icon = v.icon;

  return (
    <div className={`pv pv--fivem${compact ? " pv--compact" : ""}`} aria-hidden="true">
      <div className="pv-chrome">
        <span /><span /><span />
        <p>{v.chrome}</p>
        <span className="pv-live">FiveM</span>
      </div>
      <div className="pv-body pv-body--fivem">
        <Icon className="pv-fivem-icon" />
        <strong>{v.title}</strong>
        <span>{v.sub}</span>
        <div className="pv-fivem-bars">
          {[55, 72, 48, 80, 62].map((h, i) => (
            <div key={i} className="pv-bar" style={{ "--h": `${h}%` }} />
          ))}
        </div>
      </div>
    </div>
  );
}
