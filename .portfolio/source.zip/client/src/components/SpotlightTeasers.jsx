import { Link } from "react-router-dom";
import { FaServer, FaShieldHalved, FaArrowRight } from "react-icons/fa6";
import { useReveal } from "../hooks/useReveal.js";

function TeaserCard({ variant, platform, label, headline, text, stats, to, cta, Icon }) {
  return (
    <div className={`spotlight-teaser-copy glass-card spotlight-teaser--${variant}`}>
      <span className="spotlight-teaser-label">
        <Icon /> {platform} · {label}
      </span>
      <h3>{headline}</h3>
      <p>{text}</p>
      {stats?.length > 0 && (
        <div className="spotlight-teaser-stats">
          {stats.map((s) => (
            <div key={s.label}>
              <strong>{s.value}</strong>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      )}
      <Link to={to} className="btn btn-ghost spotlight-teaser-btn">
        {cta} <FaArrowRight />
      </Link>
    </div>
  );
}

export default function SpotlightTeasers({ razhmanFocus, foundation }) {
  const { ref, visible } = useReveal();
  const razhmanTeaser = razhmanFocus?.teaser;
  const foundationTeaser = foundation?.teaser;

  if (!razhmanTeaser && !foundationTeaser) return null;

  return (
    <section className="section section--spotlights" id="spotlights">
      <div className="container">
        <div ref={ref} className={`spotlight-teasers${visible ? " reveal--visible" : " reveal"}`}>
          {razhmanTeaser && (
            <TeaserCard
              variant="razhman"
              platform={razhmanFocus.platform || "Razhman"}
              label={razhmanFocus.label || "Current Focus"}
              headline={razhmanTeaser.headline}
              text={razhmanTeaser.text}
              stats={razhmanFocus.stats}
              to="/work"
              cta={razhmanTeaser.cta || "Explore Razhman work"}
              Icon={FaShieldHalved}
            />
          )}
          {foundationTeaser && (
            <TeaserCard
              variant="foundation"
              platform={foundation.platform || "FiveM"}
              label="Background"
              headline={foundationTeaser.headline}
              text={foundationTeaser.text}
              stats={foundation.stats?.slice(0, 3)}
              to="/foundation"
              cta={foundationTeaser.cta || "Read the full foundation story"}
              Icon={FaServer}
            />
          )}
        </div>
      </div>
    </section>
  );
}
