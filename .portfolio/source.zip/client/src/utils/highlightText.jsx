const AUTO_TERMS =
  /\b(\d+\+|VIDA|ANDE|AI Data Analyzer|Nexus Core|Razhman|FiveM|Elasticsearch|Kibana|KQL|Flask|MySQL|Lua|JavaScript|ESX|QBCore|VRP|txAdmin|RBAC)\b/gi;

function highlightAutoSegment(text, keyPrefix) {
  if (!text) return null;

  const parts = text.split(AUTO_TERMS);
  return parts.map((part, i) => {
    if (!part) return null;
    if (AUTO_TERMS.test(part)) {
      AUTO_TERMS.lastIndex = 0;
      return (
        <mark key={`${keyPrefix}-a-${i}`} className="timeline-highlight timeline-highlight--term">
          {part}
        </mark>
      );
    }
    AUTO_TERMS.lastIndex = 0;
    return part;
  });
}

/** Renders experience copy with **emphasis** and auto-highlighted metrics/terms */
export function HighlightedText({ text }) {
  if (!text) return null;

  const chunks = text.split(/(\*\*[^*]+\*\*)/g);

  return chunks.map((chunk, i) => {
    if (chunk.startsWith("**") && chunk.endsWith("**")) {
      return (
        <mark key={`h-${i}`} className="timeline-highlight">
          {chunk.slice(2, -2)}
        </mark>
      );
    }
    return <span key={`t-${i}`}>{highlightAutoSegment(chunk, `t-${i}`)}</span>;
  });
}
