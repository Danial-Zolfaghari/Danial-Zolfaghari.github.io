export function scrollToSection(id, { behavior = "smooth" } = {}) {
  const el = document.getElementById(id);
  if (!el) return false;
  el.scrollIntoView({ behavior, block: "start" });
  return true;
}

function retryScroll(sectionId, maxAttempts = 40, intervalMs = 50) {
  let attempts = 0;
  return new Promise((resolve) => {
    const tick = () => {
      if (scrollToSection(sectionId)) {
        resolve(true);
        return;
      }
      attempts += 1;
      if (attempts >= maxAttempts) {
        resolve(false);
        return;
      }
      window.setTimeout(tick, intervalMs);
    };
    tick();
  });
}

/** Navigate to a homepage section from any route, then scroll */
export function navigateToSection(navigate, pathname, sectionId) {
  const hash = `#${sectionId}`;

  if (pathname === "/" || pathname === "") {
    window.history.replaceState(null, "", hash);
    retryScroll(sectionId);
    return;
  }

  navigate({ pathname: "/", hash });
  window.setTimeout(() => retryScroll(sectionId), 80);
}
