const INTRO_KEY = "portfolio-intro-done";

export function isIntroDone() {
  try {
    return sessionStorage.getItem(INTRO_KEY) === "1";
  } catch {
    return false;
  }
}

export function markIntroDone() {
  try {
    sessionStorage.setItem(INTRO_KEY, "1");
  } catch {
    /* private browsing */
  }
}
