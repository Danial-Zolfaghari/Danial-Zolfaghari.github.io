import {
  SiPython, SiFastapi, SiFlask, SiNodedotjs, SiJavascript, SiTypescript, SiLua,
  SiMysql, SiPostgresql, SiMongodb, SiSqlite, SiElasticsearch,
  SiLinux, SiReact, SiHtml5, SiCss, SiPandas, SiNumpy,
  SiGrafana, SiKibana,
} from "react-icons/si";
import {
  FaShieldHalved, FaCode, FaBrain, FaServer, FaDatabase,
  FaChartLine, FaNetworkWired, FaRobot, FaTree, FaRoute,
  FaMagnifyingGlass, FaBookOpenReader, FaComments, FaCubes,
  FaBolt, FaBug, FaFire, FaGlobe, FaHeadset, FaChartArea,
  FaTerminal, FaLayerGroup, FaSitemap, FaGaugeHigh, FaFileLines,
  FaEye, FaWandMagicSparkles, FaGauge, FaLock, FaPlug,
  FaCircleDot, FaMicrochip, FaDiagramProject, FaEthernet,
  FaMapLocationDot, FaWaveSquare, FaBugSlash, FaHand,
} from "react-icons/fa6";

const DEVICON = {
  python: SiPython, fastapi: SiFastapi, flask: SiFlask,
  "node.js": SiNodedotjs, javascript: SiJavascript, typescript: SiTypescript, lua: SiLua,
  mysql: SiMysql, postgresql: SiPostgresql, mongodb: SiMongodb,
  sqlite: SiSqlite, elasticsearch: SiElasticsearch, linux: SiLinux,
  react: SiReact, html: SiHtml5, css: SiCss, pandas: SiPandas,
  numpy: SiNumpy, grafana: SiGrafana, kibana: SiKibana,
  powershell: FaTerminal,
};

const SEMANTIC = {
  sql: FaDatabase, "rest apis": FaPlug, aiohttp: FaBolt,
  "scikit-learn": FaChartLine, "network security": FaShieldHalved,
  "irt eoc soc": FaHeadset, "ddos detection mitigation": FaShieldHalved,
  "ddos detection": FaBugSlash, "l3 l4 traffic analysis": FaDiagramProject,
  "traffic analysis": FaChartArea, "tcp ip": FaEthernet, dns: FaGlobe,
  "firewall operations": FaFire, "incident investigation": FaMagnifyingGlass,
  "web security testing": FaBug, wireshark: FaWaveSquare, nmap: FaMapLocationDot,
  "query dsl": FaCode, kql: FaTerminal, aggregations: FaLayerGroup,
  mappings: FaSitemap, "query optimization": FaGaugeHigh,
  "log analysis": FaFileLines, "system observability": FaEye,
  "machine learning": FaBrain, llms: FaRobot, embeddings: FaCubes,
  rag: FaBookOpenReader, nlu: FaComments, "semantic retrieval": FaMagnifyingGlass,
  "hybrid retrieval": FaCode, reranking: FaGaugeHigh, "query planning": FaRoute,
  "random forest": FaTree, xgboost: FaChartLine, qwen: FaMicrochip,
  deepseek: FaMicrochip, "local llm deployment": FaServer,
  "windows server": FaServer, "system administration": FaServer,
  automation: FaWandMagicSparkles, "performance optimization": FaGauge,
  ssh: FaTerminal, paramiko: FaTerminal, "http https": FaLock, http: FaLock, https: FaLock,
  ollama: FaRobot, qwen3: FaMicrochip, rrf: FaRoute, kavenegar: FaComments, bale: FaComments,
  gunicorn: FaServer, clickhouse: FaDatabase,
};

const CATEGORY_ICON = {
  "programming backend": FaCode,
  "programming & backend": FaCode,
  "network security operations": FaShieldHalved,
  "network security & operations": FaShieldHalved,
  "data observability": FaChartLine,
  "data & observability": FaDatabase,
  "ai machine learning": FaBrain,
  "ai & machine learning": FaBrain,
  "systems web automation": FaServer,
  "systems, web & automation": FaServer,
};

function norm(s) {
  return (s || "").toLowerCase().replace(/[/\\|]+/g, " ").replace(/\s+/g, " ").trim();
}

export function TechIcon({ name, size = 12 }) {
  const n = norm(name);
  const Dev = DEVICON[n];
  if (Dev) return <Dev size={size} className="tech-icon dev" />;
  for (const [k, Icon] of Object.entries(DEVICON)) {
    if (n.includes(k)) return <Icon size={size} className="tech-icon dev" />;
  }
  const Sem = SEMANTIC[n];
  if (Sem) return <Sem size={size} className="tech-icon sem" />;
  for (const [k, Icon] of Object.entries(SEMANTIC)) {
    if (n.includes(k)) return <Icon size={size} className="tech-icon sem" />;
  }
  return <FaCircleDot size={8} className="tech-icon fallback" />;
}

export function CategoryIcon({ category, size = 11 }) {
  const n = norm(category);
  const Icon = CATEGORY_ICON[n] || FaCode;
  for (const [k, I] of Object.entries(CATEGORY_ICON)) {
    if (n.includes(k.replace(/ & /g, " "))) return <I size={size} />;
  }
  return <Icon size={size} />;
}

export const LANG_FLAGS = { persian: "🇮🇷", english: "🇬🇧", farsi: "🇮🇷" };
