const SEGMENT_ORDER = { Razhman: 0, FiveM: 1 };

export function getProjectSlug(project) {
  if (project.slug) return project.slug;
  return project.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function findProjectBySlug(projects, slug) {
  return (projects || []).find((p) => getProjectSlug(p) === slug);
}

export function sortProjects(projects) {
  return [...(projects || [])].sort((a, b) => {
    if (a.topPick !== b.topPick) return b.topPick ? 1 : -1;

    const segA = SEGMENT_ORDER[a.segment] ?? 99;
    const segB = SEGMENT_ORDER[b.segment] ?? 99;
    if (segA !== segB) return segA - segB;

    const orderA = a.sortOrder ?? 99;
    const orderB = b.sortOrder ?? 99;
    if (orderA !== orderB) return orderA - orderB;

    if (a.featured !== b.featured) return b.featured ? 1 : -1;
    return 0;
  });
}

export function filterProjects(projects, category, query) {
  const q = query.trim().toLowerCase();
  return (projects || []).filter((p) => {
    let matchCat = true;
    if (category === "Razhman") matchCat = p.segment === "Razhman";
    else if (category === "FiveM") matchCat = p.segment === "FiveM";
    else if (category !== "All") matchCat = p.category === category;

    const matchQ =
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.expansion?.toLowerCase().includes(q) ||
      p.summary?.toLowerCase().includes(q) ||
      p.tagline?.toLowerCase().includes(q) ||
      p.segment?.toLowerCase().includes(q) ||
      p.technologies?.some((t) => t.toLowerCase().includes(q));

    return matchCat && matchQ;
  });
}

export function groupProjects(projects, category, query, groupsMeta = {}) {
  const sorted = sortProjects(projects);
  const showGrouped = category === "All" && !query.trim();

  if (!showGrouped) {
    return [{ id: "all", label: null, description: null, projects: sorted }];
  }

  const razhman = sorted.filter((p) => p.segment === "Razhman");
  const fivem = sorted.filter((p) => p.segment === "FiveM");

  return [
    {
      id: "razhman",
      label: groupsMeta.razhman?.label || "Top picks · Razhman",
      description: groupsMeta.razhman?.description || null,
      projects: razhman,
    },
    {
      id: "fivem",
      label: groupsMeta.fivem?.label || "Top picks · FiveM",
      description: groupsMeta.fivem?.description || null,
      projects: fivem,
    },
  ].filter((g) => g.projects.length > 0);
}

export function getAdjacentProjects(projects, slug) {
  const sorted = sortProjects(projects);
  const idx = sorted.findIndex((p) => getProjectSlug(p) === slug);
  if (idx === -1) return { prev: null, next: null };
  return {
    prev: idx > 0 ? sorted[idx - 1] : null,
    next: idx < sorted.length - 1 ? sorted[idx + 1] : null,
  };
}

export function getTopPicks(projects, segment) {
  return sortProjects(projects).filter(
    (p) => p.topPick && (!segment || p.segment === segment)
  );
}
