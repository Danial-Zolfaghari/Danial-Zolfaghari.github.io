import { BrowserRouter, Routes, Route } from "react-router-dom";
import PageShell from "./components/layout/PageShell.jsx";
import HomePage from "./pages/HomePage.jsx";
import ProjectsPage from "./pages/ProjectsPage.jsx";
import ProjectDetailPage from "./pages/ProjectDetailPage.jsx";
import FoundationPage from "./pages/FoundationPage.jsx";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<PageShell />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/work" element={<ProjectsPage />} />
          <Route path="/work/:slug" element={<ProjectDetailPage />} />
          <Route path="/foundation" element={<FoundationPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
