@echo off
cd /d "%~dp0"
echo Starting Danial Portfolio...
npm run dev
pause
