import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, "..");
const CLIENT_DIST = path.join(ROOT, "client", "dist");
const PROFILE_PATH = path.join(__dirname, "data", "profile.json");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get("/api/profile", (_req, res) => {
  res.json(JSON.parse(fs.readFileSync(PROFILE_PATH, "utf-8")));
});

if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(CLIENT_DIST, "index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`Portfolio API → http://localhost:${PORT}/api/profile`);
  if (fs.existsSync(CLIENT_DIST)) {
    console.log(`Portfolio site → http://localhost:${PORT}`);
  } else {
    console.log(`Dev client   → http://localhost:5173 (run npm run dev)`);
  }
});
