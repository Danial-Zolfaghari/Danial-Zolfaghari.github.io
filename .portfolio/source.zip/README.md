# Danial Zolfaghari — Personal Portfolio

A professional portfolio website built with **React + Node.js**.

Not a resume builder — a personal site to introduce yourself, showcase projects, skills, and experience.

## Stack

- **React (Vite)** — frontend UI
- **Node (Express)** — API + production static hosting
- **Dark emerald theme** — custom design

## Run locally

```powershell
cd F:\karbordi\Desktop\Portofolio

npm install
npm install --prefix server
npm install --prefix client

npm run dev
```

Open **http://localhost:5173**

## Production

```powershell
npm run build
npm start
# → http://localhost:4000
```

## Edit content

Update `server/data/profile.json` — the site loads data from `/api/profile`.

## Structure

```
Portofolio/
├── client/src/components/   React UI sections
├── server/data/profile.json  Your content
└── server/index.js          Express API
```
